import java.io.*;

public class Palindroom
{
    private static final String INFILE = "Palindroom.txt";
    
    public static void main(String [] args)
    {        
        try
        {
            Reader fis = new InputStreamReader(System.in);
            BufferedReader br = new BufferedReader(fis);
            
            String regel = br.readLine();
            int aantal = Integer.parseInt(regel);
            
            for (int k = 1; k <= aantal; k++)
            {
                regel = br.readLine();
                Problem problem = new Problem(regel);                                                                     
                System.out.println(""+ problem.getSolution());                       
            }
            System.in.read();
        }
        catch (IOException iox){}
    }        
}

class Problem
{
    private String regel;
    int lengte;
    private int [][] dromen; 
    // dromen[k][l] bevat de lengte van het langste palindroom in regel(k).. regel(l)
    
    public Problem(String s)
    {
        regel  = s;
        lengte = s.length();
        dromen = new int[lengte][lengte];        
    }
    
    public int getSolution()
    {
        vularray();
        return lengte - dromen[0][lengte - 1];
    }
        
    private void vularray()
    {
        for (int eind = 0; eind < lengte; eind++)
            for (int start = eind; start >= 0; start--)
                dromen [start][eind] = bereken(start, eind);
    }
            
    private int bereken(int start, int eind)
    // voorwaarde: start <= eind 
    {
        if (start == eind)
            return 1; 
        int met, zonder; //met resp. zonder het eerste character        
        zonder = dromen [start + 1][eind];
                
        while(regel.charAt(eind) != regel.charAt(start))
            eind--;
        if (eind == start)
            met = 1;
        else if (eind == start + 1)
                met = 2;
             else 
                met = 2 + dromen [start + 1][eind - 1];
        
        return Math.max(met, zonder);        
    }
}
