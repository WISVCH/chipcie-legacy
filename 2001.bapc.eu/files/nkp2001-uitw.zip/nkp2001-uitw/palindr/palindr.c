/*
 *  Oplossing voor de opgave "Palindromie".
 *  Joris van Rantwijk, Mar 2001.
 *  Algoritme: dynamisch programmeren.
 */

#include <stdio.h>
#include <string.h>

#define MAXWORDLEN 200

/* min[i][j] = het minimaal aantal te verwijderen letters om van
   de substring met lengte j vanaf letter i een palindroom te maken */
unsigned char min[MAXWORDLEN][MAXWORDLEN+1];

int minskip(const char *str)
{
	int i, k, len;

	len = strlen(str);

	/* Woorden van lengte 0 en 1 zijn altijd palindromen */
	for (i = 0; i < len; i++) {
		min[i][0] = 0;
		min[i][1] = 0;
	}

	/* Beschouw nu substrings met lengte k = 2, 3, .. len. */
	for (k = 2; k <= len; k++) {
		for (i = 0; i + k <= len; i++) {

			/* A: Knip de laatste letter weg, en vorm het langste
			      palindroom met de rest van de letters. */
			unsigned int m = min[i][k-1] + 1;

			/* B: Knip de eerste letter weg, en vorm het langste
			      palindroom met de rest van de letters. */
			if (min[i+1][k-1] + 1 < m)
				m = min[i+1][k-1] + 1;

			/* C: Match de eerste letter met de laatste, en voeg
			      het langste palindroom uit de rest er tussen. */
			if (str[i] == str[i+k-1] && min[i+1][k-2] < m)
				m = min[i+1][k-2];

			min[i][k] = m;
		}
	}

	return min[0][len];
}

int main(void)
{
	int n;
	char str[MAXWORDLEN+10];

	scanf("%d\n", &n);

	while ((n--) > 0) {
		fgets(str, sizeof(str), stdin);
		if (strlen(str) > 0 && str[strlen(str)-1] == '\n')
			str[strlen(str)-1] = '\0';
		printf("%d\n", minskip(str));
	}

	return 0;
}

/* end */
