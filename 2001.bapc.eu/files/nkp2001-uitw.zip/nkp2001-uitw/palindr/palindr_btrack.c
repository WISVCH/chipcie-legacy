/*
 *  Backtracking oplossing voor de opgave "Palindromie".
 *  Joris van Rantwijk, Jan 2001.
 *  Algoritme: gewoon brute-force backtracken met een
 *    paar simpele pruning strategien.
 */

#include <stdio.h>
#include <string.h>

/*
 *  Recursieve backtrack functie.
 *  Beschouw de string str[0 .. len-1], en bepaal het kleinste aantal
 *  letters dat hieruit moet worden verwijderd om een palindroom te vormen.
 *  We gebruiken alfa-pruning: als er meer dan alfa letters verwijderd
 *  moeten worden, laat het dan helemaal maar zitten (en return gewoon alfa).
 */
int minskip(const char *str, int len, int alfa)
{
	int i, j, a, min;

	/* Alle woorden van lengte 0 en 1 zijn palindromen */
	if (len <= 1)
		return 0;

	/* Alle letters op 1 na weghalen kan altijd */
	min = len - 1;

	/* Meer dan alfa letters weghalen heeft geen nut */
	if (alfa < min)
		min = alfa;

	/* We kiezen twee matchende letters, en snijden het voor-
	   en achterstuk weg. Daarna recursieve aanroep voor de
	   string tussen de matchende letters. */

	/* Kies een beginletter */
	for (i = 0; i < len; i++) {

		/* Bepaal de (eerst gevonden) matchende eindletter */
		for (j = len-1; j > i && str[i] != str[j]; j--) ;

		if (j > i) {
			/* Hoeveel letters snijden we nu weg ? */
			a = i + len - j - 1;

			/* Heeft dat wel zin ? (alfa/min-prune) */
			if (a < min) {
				/* Recursieve aanroep */
				a += minskip(str+i+1, j-i-1, min-a);

				/* Is dit beter dan wat we hadden ? */
				if (a < min)
					min = a;
			}
		}

		/* Nooit een "gratis" match overslaan */
		if (j == len-1)
			break;
	}

	/* Return het door ons gevonden minimum */
	return min;
}

int main(void)
{
	int n;
	char str[300];

	scanf("%d\n", &n);

	while ((n--) > 0) {
		fgets(str, sizeof(str), stdin);
		if (strlen(str) > 0 && str[strlen(str)-1] == '\n')
			str[strlen(str)-1] = '\0';
		printf("%d\n", minskip(str, strlen(str), strlen(str)));
	}

	return 0;
}

/* end */
