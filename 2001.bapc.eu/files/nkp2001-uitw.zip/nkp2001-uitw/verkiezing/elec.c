#include <stdlib.h>
#include <stdio.h>
#define MAXCITIES 20
FILE *fin;
int n,minvotes,citizenvotes[MAXCITIES];

int globalpos;
int globaltotvotes;
int globaldiff;
int globaltvotes[MAXCITIES];

void solverecglobal() {
	int i,add;
	if (globalpos==n || (minvotes!=0 && minvotes<globaltotvotes))
		return;
	if (globaldiff<0) {
		minvotes = globaltotvotes;
		return;
	}
	if (globaltvotes[globalpos]==0) {
		int savetotvotes = globaltotvotes;
		int savediff = globaldiff;
		globaltvotes[globalpos]=citizenvotes[globalpos]+1;
		if (globaltvotes[globalpos]<501)
			globaltvotes[globalpos]=1000-citizenvotes[globalpos];
		globaltotvotes += globaltvotes[globalpos];
		globaldiff -= ((globaltvotes[globalpos]+citizenvotes[globalpos])/1000)+(citizenvotes[globalpos]/1000);
		solverecglobal();
		globaltvotes[globalpos]=0;
		globaldiff = savediff;
		globaltotvotes = savetotvotes;
	} else {
		int savetvotes = globaltvotes[globalpos];
		int savetotvotes = globaltotvotes;
		int savediff = globaldiff;
		globaltvotes[globalpos] += (add=1000-((citizenvotes[globalpos]+globaltvotes[globalpos])%1000));
		globaltotvotes += add;
		globaldiff--;
		if (globaldiff>0) {
			globaltotvotes+=globaldiff*1000;
			globaltvotes[globalpos] += globaldiff*1000;
			globaldiff=0;
		}
		solverecglobal();
		globaldiff = savediff;
		globaltvotes[globalpos] = savetvotes;
		globaltotvotes = savetotvotes;
	}
	globalpos++;
	solverecglobal();
	globalpos--;
}

int main(void) {
        int run, i,diff;
/*        fin = fopen("elections.in", "r"); */
	fin = stdin;
        fscanf(fin, "%d\n", &run);
        while ((run--) > 0) {
                fscanf(fin, "%d\n", &n);
                globaldiff=0;
                for (i=0;i<n;i++) {
                	fscanf(fin, "%d\n", &citizenvotes[i]);
                	globaldiff+=citizenvotes[i]/1000;
                	globaltvotes[i]=0;
                }
                minvotes=0;
		globalpos = 0;
		globaltotvotes = 0;
		solverecglobal();
                printf("%d\n", minvotes);
        }
        fclose(fin);
        return 0;
}
