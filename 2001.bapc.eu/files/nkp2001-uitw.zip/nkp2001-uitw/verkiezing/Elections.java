import java.io.*;
import java.util.*;

public class Elections
{
    private static final String INFILE = "Elections.in";
    
    public static void main(String [] args)
    {        
        //try
        //{
            //FileInputStream fis = new FileInputStream(INFILE);
            IntReader ir = new IntReader(System.in);                        
            
            int cases = ir.read();
            for (int k = 0; k < cases; k++)                       
            {                
                int cities = ir.read();
                Problem problem = new Problem(cities, ir);                           
                problem.solve();                               
                System.out.println(problem.getSolution());                           
            }
                            
            //System.in.read();
        //}
        //catch (IOException iox){}
    }        
}

class Problem
{
    int [] votes;
    int cities;
    int kiesmannen;
    int minNomads;
    
    public Problem(int c, IntReader ir)
    {
        cities = c;  
        minNomads = Integer.MAX_VALUE;
        votes = new int [cities];
        for (int k = 0; k < cities; k++)
        {
           votes[k] = ir.read();         
           kiesmannen += votes[k]/1000;           
        }                      
    }
        
    public void solve()
    {
        recusolve (cities - 1, - kiesmannen, 0);        
    }
        
    private void recusolve(int k, int mannen, int voters)
    {
        if (k < 0 || mannen > 0)
            complete(mannen, voters);
        else
        if (voters < minNomads) 
        {            
            recusolve(k - 1, mannen, voters); // stuur hier geen enkele Nomade heen
            
            voters += votes[k] + 1; // stuur hier een meerderheid(+1) aan Nomaden heen
            mannen += (2 * votes[k] + 1) /1000 + votes[k]/1000;
            recusolve(k - 1, mannen, voters);
            
            voters += 1000 - (2 * votes[k] + 1) % 1000; // vul vervolgens aan tot 1000-voud
            mannen += 1;
            recusolve(k - 1, mannen, voters);            
        }        
    }
    
    private void complete(int mannen, int voters)
    {        
        if (mannen <= 0) // zonodig extra mannen kopen voor 1000 stemmen per man
        {
            voters += 1000 * (1 - mannen);
            mannen = 1;               
        }               
        if (voters < minNomads)
            minNomads = voters;            
    } 
    
    public String getSolution()
    {
        return "" + minNomads;
    }
}

class IntReader extends StreamTokenizer
{
    public IntReader(InputStream is)
    {
        super(is);
    }
    
    public int read()
    {
        try
        {
            int tokentype = nextToken();                 
        }        
        catch(IOException iox){}
        return (int) nval; 
    }    
}
