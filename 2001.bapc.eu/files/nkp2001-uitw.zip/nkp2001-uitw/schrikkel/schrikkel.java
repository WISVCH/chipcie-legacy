import java.io.*;

public class schrikkel {
    
    public static void main (String args[]) {new schrikkel();}
        
    private int[][] jaren = new int[1000][2];
    
    public schrikkel () {
        try {                                                   // We beginnen met wat initialisaties
            StreamTokenizer tok = new StreamTokenizer(new InputStreamReader(System.in));
            tok.resetSyntax(); tok.whitespaceChars(0, 32); tok.wordChars(33, 127);

            tok.nextToken();
            int runs = Integer.parseInt(tok.sval);              // Het aantal runs
            
            int n, basis = 0, periode, sum;                     // Een paar hulpvariabelen
            boolean ok;
            String str;
            
            while ((runs--) > 0) {                              // Nu gaan we alle runs doorlopen
            
                tok.nextToken();
                n = Integer.parseInt(tok.sval);                 // Het aantal jaren in de regeling
                
                for (int i = 0; i < n; i++) {                   // We lezen alle jaren in
                    tok.nextToken();
                    jaren[i][0] = Integer.parseInt(tok.sval);
                    tok.nextToken();
                    jaren[i][1] = Integer.parseInt(tok.sval);
                    if (jaren[i][0] == 1) basis = jaren[i][1];  // Het basisjaar onthouden we
                    ok = true;
                    for (int j = 0; j < i && ok; j++) {
                        if (jaren[i][0] % jaren[j][0] == 0) {   // Overbodige jaren gooien we weg
                            ok = false; i--; n--;
                        }
                    }
                }
                
                periode = kgv_jaren(n);                         // We berekenen nu de 'schrikkelperiode'
                sum = 0;                                        // De som wordt het aantal schrikkeldagen in de hele periode
                for (int i = 0; i < periode; i++) {             // We gaan alle jaren in de periode af
                    ok = true;
                    for (int j = 0; (j < n && ok); j++) {       // We kijken hoeveel dagen ieder jaar met de basis verschilt
                        if (i % jaren[j][0] == 0) {
                            sum += jaren[j][1] - basis;
                            ok = false;
                        }
                    }
                }
                // Rond het antwoord nog even netjes af
                str = "" + java.lang.Math.round(((basis + (double)sum / (double)periode) * 100000));
                System.out.println(str.substring(0, str.length()-5) + "." + str.substring(str.length()-5));
            }
        }
        catch (IOException e) { System.err.println(e); }
    }
    
    private int kgv_jaren (int n) {     // Zoek het kgv van alle jaartallen
        if (n == 1) return jaren[0][0];
        int cur = kgv(jaren[0][0],jaren[1][0]);
        for (int i = 2; i < n; i++) { cur = kgv(cur,jaren[i][0]); }
        return cur;
    }
    
    private int kgv (int a, int b) {    // Geef het kgv van twee getallen
        if (a < b) { int c = a; a = b; b = c; }
        for (int i = 1; i <= b; i++) { if ((a * i) % b == 0) return a * i; }
        return -1;
    }
}