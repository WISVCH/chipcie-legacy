#include <stdio.h>
#include <assert.h>

int gcd(int a, int b)
{
  while(a)
    {
      int t = b%a;
      b = a;
      a = t;
    }
  return b;
}

int main(void)

{
  int R;

  int D[100],L[100];

/*  freopen("d.in","r",stdin); */
  for(scanf("%d",&R);R--;)
    {
      int NSR,NUR, i,j, PERIOD, flag;
      double sum_length;
      scanf("%d",&NSR);
      assert(NSR>=1);
      assert(NSR<=20);
      fprintf(stderr,"number of specified rules: %d\n",NSR);
      flag = 0;
      for(NUR=0;NSR--;)
	{
	  scanf("%d%d",&D[NUR],&L[NUR]);
	  assert(D[NUR]>=1);
	  assert(D[NUR]<=10000);
	  assert(L[NUR]>=1);
	  assert(L[NUR]<=10000);
	  if (D[NUR]==1) flag=1;
	  for(i=0;i<NUR;i++)
	    {
	      if (D[NUR]%D[i]==0)
		break;
	    }
	  if (i==NUR)
	    {
	      fprintf(stderr,"using rule: %d %d\n", D[NUR],L[NUR]);
	    }
	  else
	    {
	      fprintf(stderr,"ignoring rule: %d %d\n", D[NUR], L[NUR]);
	    }
	  NUR+=(i==NUR);
	}
      assert(flag);

      PERIOD = 1;
      for(i=0;i<NUR;i++)
	{
	  PERIOD= PERIOD/gcd(PERIOD,D[i])*D[i];
	}

      fprintf(stderr,"done case, PERIOD=%d\n",PERIOD);
      assert(PERIOD>=1);
      assert(PERIOD<=10000);

      sum_length = 0;
      for(i=0;i<PERIOD;i++)
	for(j=0;j<NUR;j++)
	  if (i%D[j]==0)
	    {
	      sum_length+=L[j];
	      break;
	    }

      printf("%.5f\n",sum_length/PERIOD);
    }
  return 0;
}
