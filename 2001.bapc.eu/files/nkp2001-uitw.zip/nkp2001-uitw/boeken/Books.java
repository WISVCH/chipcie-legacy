/* Solution in Java for the problem Books, ICPC2001
 * author   P.G.Kluit
 * date     July 2000
 * strategy Algoritm 2 in Algoritm.doc
 *          heights and depths are replaced by serial numbers,
 *          this conversion is done by the class Ascending
 *
 * May 2001 adapted for NKP 2001
 */

import java.io.*;
import java.util.*;

public class Books
// driver, just the method main, that reads and solves the testcases
{
    private static final String INFILE = "boeken.in";

    public static void main(String [] args)
    {
        try
	    {
                Reader in = new InputStreamReader(System.in);
	            BufferedReader br = new BufferedReader(in);
	                IntReader ir = new IntReader(br);

	        int aantal = ir.read();
	        for(int k = 0; k < aantal; k++)
	        {
	            Problem problem = new Problem(ir);
	            problem.solve();
	            problem.printSolution(System.out);
	        }
	        // System.in.read();
	        in.close();
	    }
	    catch (IOException ioe){ System.out.println("foutje");}
    }
}

class Problem
// representation of a testcase
{
    private static final int WIDTHOFBOOK = 20;

    IntReader input;
    Vector shelves = new Vector(); // keeps the shelves during reading
    Balance balance;

    public Problem(IntReader strtok) throws IOException
    /* a Problem is read from the tokenizer
     * first the bookcases are read, and the shelves are stored in 'shelves'.
     * then the heights and depths of the shelves are stored in 'heights' and 'depths'
     * using these, balance is created.
     * next the shelves are stored in balance
     * finally the books are read and added to balance.
     */
    {
        input = strtok;
        int numOfBookcases = input.read();

        for (int k = 0; k < numOfBookcases; k++)
            readBookcase(strtok); // and put them in shelves

        Ascending heights = new Ascending(shelves.size());
        Ascending depths  = new Ascending(shelves.size());

        for (int index = 0; index < shelves.size(); index++)
        {
            Shelf shelf = (Shelf) shelves.elementAt(index);
            depths.insert(shelf.depth);
            heights.insert(shelf.height);
        }

        balance = new Balance(depths, heights);

        for (int index = 0; index < shelves.size(); index++)
        {
            Shelf shelf = (Shelf) shelves.elementAt(index);
            balance.addShelf(shelf);
        }
        int numOfBooks = input.read();
        for (int k = 0; k < numOfBooks; k++)
            readBook();
    }

    public void solve()
    {
        balance.sweep();
    }

    public void printSolution(PrintStream out)
    {
        out.println(balance.getRest());
    }

    private void readBookcase(StreamTokenizer strtok)
    {
        int width = input.read();
        int widthInBooks = width / WIDTHOFBOOK;
            // the number of books that will fit into a single shelf in this bookcase
        int depth = input.read();
        int noOfShelves = input.read();

        for (int k = 0; k < noOfShelves; k++)
        {
            int height = input.read();
            Shelf shelf = new Shelf(widthInBooks, depth, height);
            shelves.addElement(shelf);
        }
    }

    private void readBook()
    // reads a book and stores it in the balance.
    {
        int depth  = input.read();
        int height = input.read();
        balance.addBook(depth, height);
    }
}

class Shelf
{
    int capacity;      // number of books it may contain
    int depth, height; // dimension

    public Shelf(int cap, int d, int h)
    {
        capacity = cap;
        depth = d;
        height = h;
    }
}

class Balance
{
    int[][] balance;
    /* balance contains the books and locations of a given size
     * where the indices are the indices of depth and height.
     * the number of books of a certain size is stored as a positive number
     * the number of locations of a given size is stored as a negative number
     * thus automatically books are placed in locations of the same size.
     */

    Ascending depths;   // replaces a depth with an index
    Ascending heights;  // replaces a height with an index

    public Balance(Ascending depths, Ascending heights)
    {
        this.depths  = depths;
        this.heights = heights;
        int numOfHeights = heights.size();
        int numOfDepths  = depths.size();
        balance = new int [numOfDepths] [numOfHeights];
        for(int i = 0; i < numOfDepths; i++)
            for(int j = 0; j < numOfHeights; j++)
                balance[i][j] = 0;
    }

    public void addShelf(Shelf shelf)
    {
        int depthindex  = depths.ceil(shelf.depth);
        int heightindex = heights.ceil(shelf.height);
        balance[depthindex][heightindex] -= shelf.capacity;
    }

    public void addBook(int depth, int height)
    {
        int depthindex  = depths.ceil(depth);
        int heightindex = heights.ceil(height);
        balance[depthindex][heightindex]++;
    }

    public void sweep()
    /* here it happens
     * read Analysis.doc (Algoritm 2) for explanation of the algoritm
     */
    {
        for (int hindex = 0; hindex < heights.size()-1; hindex++)
            for (int dindex = depths.size() -1; dindex >= 0; dindex --)
            {
                int item = balance[dindex][hindex];
                if (item < 0) // locations leftover
                    if (dindex > 0)
                        balance[dindex -1][hindex] += item; //shrink locations
                if (item > 0) // books leftover
                    balance [dindex][hindex+1] += item; //grow books
                balance[dindex][hindex] = 0;
            }
    }

    public int getRest()
    // returns the number of books of height Ascending.BIG
    {
        int answer = 0;
        int hindex = heights.ceil(Ascending.BIG);
        for (int dindex = 0; dindex < depths.size(); dindex++)
            answer += balance[dindex][hindex];
        return answer;
    }

    public void dump() //just for debugging purposes...
    {
        for(int j = heights.size() -1; j>=0; j--)
        {
           for(int i = 0; i < depths.size(); i++)
                System.out.print (" " + balance[i][j]);
           System.out.println();
        }
        System.out.println();
    }
}

class Ascending
// implements a strictly ascending sequence of integers
{
    public static final int BIG = Integer.MAX_VALUE;
    int [] elements; //contains the elements in ascending order
    int lastIndex;

    public Ascending(int size)
    {
        elements = new int [size + 1]; // one extra for the sentinel
        elements[0] = BIG; //sentinel
        lastIndex = 0;
    }

    public int size()
    // returns the number of elements
    {
        return lastIndex + 1;
    }

    public void insert(int k)
    // if k is not present, k is inserted, keeping the sequence sorted
    // condition: k <= BIG
    {
        int index = ceil(k);
        if (elements[index] > k)
        {
            for(int m = lastIndex; m >= index; m--)
                elements[m+1] = elements[m];
            lastIndex++;
            elements[index] = k;
        }
    }

    public int ceil(int k)
    // returns the index of the least item not less than k
    //      (say that again, please?)
    // condition: k <= BIG
    {
        int index = 0;
        while(elements[index] < k) // indeed, binary search is faster
            index++;
        return index;
    }
}

class IntReader extends StreamTokenizer
{
    public IntReader(Reader is)
    {
        super(is);
    }

    public int read()
    {
        try
        {
            int tokentype = nextToken();
        }
        catch(IOException iox){}
        return (int) nval;
    }
}
