/*
 *  Oplossing voor de opgave "Books".
 *  Joris van Rantwijk, Apr 2001.
 */

#include <stdio.h>
#include <assert.h>

#define MAXBOOKCASES	10
#define MAXSHELVES	10
#define MAXBOOKS	1000
#define MAXSIZE		1001

int n_bookcase;
int bookcase_width[MAXBOOKCASES];
int bookcase_depth[MAXBOOKCASES];
int bookcase_n_shelf[MAXBOOKCASES];
int shelf_height[MAXBOOKCASES][MAXSHELVES];
int n_book;
int book_depth[MAXBOOKS];
int book_height[MAXBOOKS];

/*
 *  IDEE: We stoppen de boeken in de kasten, beginnend bij de boeken
 *  met de grootste hoogte; als er boeken met gelijke hoogte zijn,
 *  nemen we daarvan eerst de boeken met de grootste diepte.
 *  Gegeven een boek met diepte d en hoogte h; we beschouwen alle
 *  vrije plekjes met diepte >= d en hoogte >= h, en kiezen het
 *  plekje met de kleinste diepte; als dit er meer dan 1 is kiezen
 *  we daarvan het plekje met kleinste hoogte. Als zo'n plekje niet
 *  bestaat, past het boek niet in de kast.
 *
 *  Het aantal boeken dat we op deze manier overhouden is minimaal.
 *  Ik heb er geen bewijs voor, maar het klopt echt. Heus waar. Ik
 *  weet het zeker, denk ik.
 */

int find_leftover_books(void)
{
	int i, j, k;
	int leftover;
	int shelf_room[MAXBOOKCASES][MAXSHELVES];

	/* Sorteer boeken op hoogte en diepte */
	for (i = 1; i < n_book; i++) {
		int d, h;
		d = book_depth[i];
		h = book_height[i];
		for (j = i; j >= 1; j--) {
			if (book_height[j-1] > h ||
			    (book_height[j-1] == h && book_depth[j-1] >= d))
				break;
			book_depth[j] = book_depth[j-1];
			book_height[j] = book_height[j-1];
		}
		book_depth[j] = d;
		book_height[j] = h;
	}

	/* Bereken vrije ruimte op planken */
	for (i = 0; i < n_bookcase; i++) {
		for (j = 0; j < bookcase_n_shelf[i]; j++)
			shelf_room[i][j] = bookcase_width[i] / 20;
	}

	/* Plaats boeken op de planken */
	leftover = 0;

	for (i = 0; i < n_book; i++) {
		int d, h;
		int bestc, bests, bestd, besth;
 
		d = book_depth[i];
		h = book_height[i];

		bestc = -1; bests = -1;
		bestd = MAXSIZE; besth = MAXSIZE;

		/* Zoek beste plekje voor dit boek */
		for (j = 0; j < n_bookcase; j++) {
			if (bookcase_depth[j] < d || bookcase_depth[j] > bestd)
				continue;
			for (k = 0; k < bookcase_n_shelf[j]; k++) {
				if (shelf_room[j][k] <= 0 ||
				    shelf_height[j][k] < h)
					continue;
				if (bookcase_depth[j] < bestd ||
				    (bookcase_depth[j] == bestd &&
				     shelf_height[j][k] < besth)) {
					bestc = j;
					bests = k;
					bestd = bookcase_depth[j];
					besth = shelf_height[j][k];
				}
			}
		}

		if (bestc == -1) {
			/* Er is geen plek */
			leftover++;
		} else {
			/* Zet het boek op zijn plekje */
			shelf_room[bestc][bests]--;
		}
	}

	return leftover;
}


int main(void)
{
	int i, j;
	int runs;

	scanf("%d", &runs);

	while (runs-- > 0) {

		scanf("%d", &n_bookcase);
		assert(n_bookcase < MAXBOOKCASES);

		for (i = 0; i < n_bookcase; i++) {
			scanf("%d %d %d", &bookcase_width[i],
			      &bookcase_depth[i], &bookcase_n_shelf[i]);
			assert(bookcase_width[i] < MAXSIZE);
			assert(bookcase_depth[i] < MAXSIZE);
			assert(bookcase_n_shelf[i] > 0);
			assert(bookcase_n_shelf[i] < MAXSHELVES);

			for (j = 0; j < bookcase_n_shelf[i]; j++) {
				scanf("%d", &shelf_height[i][j]);
				assert(shelf_height[i][j] < MAXSIZE);
			}
		}

		scanf("%d", &n_book);
		assert(n_book < MAXBOOKS);

		for (i = 0; i < n_book; i++) {
			scanf("%d %d", &book_depth[i], &book_height[i]);
			assert(book_depth[i] < MAXSIZE);
			assert(book_height[i] < MAXSIZE);
		}

		assert(n_bookcase > 0);

		printf("%d\n", find_leftover_books());

	}

	return 0;
}

/* end */
