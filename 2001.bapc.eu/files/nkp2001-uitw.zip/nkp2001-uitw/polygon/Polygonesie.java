/* Polygonesie oplossing van Lian Ien */

import java.io.*;
import java.util.*;
public class Polygonesie
{
    public static void main(String[] args)
    {
        int aantalSituaties;

        try
        {
            StreamTokenizer f = new StreamTokenizer(new InputStreamReader(System.in));
//            StreamTokenizer f = new StreamTokenizer(new FileInputStream("polygonesie.in"));
            f.resetSyntax();
            f.whitespaceChars(0, 0x20);
            f.wordChars(0x21, 0xff);
            f.nextToken();
            aantalSituaties = Integer.parseInt(f.sval);

            for (int i = 0; i < aantalSituaties; i++)
            {
                // lees het aantal eilanden in
                f.nextToken();
                int aantalEilanden = Integer.parseInt(f.sval);
                int[] aantalHoekpunten = new int[aantalEilanden];
                
                Punt[][] hoekpunten = new Punt[aantalEilanden][20];
                
                // lees voor alle eilanden alle hoekpunten in
                for (int j = 0; j < aantalEilanden; j++)
                {
                    // lees het aantal hoekpunten in
                    f.nextToken();
                    aantalHoekpunten[j] = Integer.parseInt(f.sval);
                    
                    for (int k = 0; k < aantalHoekpunten[j]; k++)
                    {
                        // lees de x-coordinaat in
                        f.nextToken();
                        int dezeX = Integer.parseInt(f.sval);
                        
                        // lees de y-coordinaat in
                        f.nextToken();
                        int dezeY = Integer.parseInt(f.sval);
                        
                        hoekpunten[j][k] = new Punt(dezeX, dezeY);
                    }
                }
                
                // lees de positie van de Kleine Kapitein in
                
                // lees de x-coordinaat in
                f.nextToken();
                int kleineKapiteinX = Integer.parseInt(f.sval);
                
                // lees de y-coordinaat in
                f.nextToken();
                int kleineKapiteinY = Integer.parseInt(f.sval);
                
                Punt kleineKapiteinPositie = 
                    new Punt(kleineKapiteinX, kleineKapiteinY);
                
                // nu zijn alle gegevens ingelezen
                
                // idee:
                // - ga voor alle eilanden na welk deel van de horizon door
                // dit eiland beslagen wordt
                // - streep de overlappende stukken weg
                
                boolean erLooptEenEilandOmDeBootHeen = false;

                // in de array eilandgrenzen[][] worden de grenzen van het 
                // eiland opgeslagen:
                // eilandgrenzen[i][0] = begin van het eiland
                // eilandgrenzen[i][1] = eind van het eiland
                // eilandgrenzen[i][2] = 0 als je niet door '0' heen gaat
                //                       1 als je wel door '0' heen gaat
                double eilandgrenzen[][] = new double[aantalEilanden][3];
                
                for (int j = 0; j < aantalEilanden; j++)
                {
                    // initialiseer de waarden op -1, -1, 0
                    eilandgrenzen[j][0] = -1;
                    eilandgrenzen[j][1] = -1;
                    eilandgrenzen[j][2] = 0;
                    
                    double hoek1 = bepaalHoek(hoekpunten[j][0], kleineKapiteinPositie);
                    double hoek2 = bepaalHoek(hoekpunten[j][1], kleineKapiteinPositie);
                    
                    double max = Math.max(hoek1, hoek2);
                    double min = Math.min(hoek1, hoek2);
                    
                    if ((((2*Math.PI) - max) + min) < Math.PI)
                    {
                        // het eiland gaat door '0' heen
                        eilandgrenzen[j][2] = 1;
                        
                        eilandgrenzen[j][0] = max;
                        eilandgrenzen[j][1] = min;
                    }
                    else
                    {
                        eilandgrenzen[j][0] = min;
                        eilandgrenzen[j][1] = max;
                    }
                    
                    // nu zijn de eilandgrenzen van dit eiland
                    // geinitialiseerd op het eerste lijnstuk
                    
                    // ga nu alle volgende hoekpunten af en pas de
                    // eilandgrenzen steeds aan aan de nieuwe gegevens
                    
                    for (int k = 2; k < aantalHoekpunten[j]; k++)
                    {
                        double vorigeHoek = bepaalHoek(hoekpunten[j][k-1], kleineKapiteinPositie);
                        double dezeHoek = bepaalHoek(hoekpunten[j][k], kleineKapiteinPositie);
                        
                        // als deze hoek ligt in het stuk wat je al gehad 
                        // hebt --> doe niets
                        if ((ligtInHetStukWatJeAlGehadHebt(dezeHoek, eilandgrenzen[j][0], eilandgrenzen[j][1], eilandgrenzen[j][2])))
                        {
                            // kijk of het eiland om de boot heen loopt

                            double max2 = Math.max(vorigeHoek, dezeHoek);
                            double min2 = Math.min(vorigeHoek, dezeHoek);
                            
                            // kijk of de lijn zowel door het begin als het eind heen 
                            // gaat --> als dit niet zo is, dan loopt het eiland niet
                            // om de boot heen
                            if(((min2 <= eilandgrenzen[j][0]) 
                                    && (max2 >= eilandgrenzen[j][0]))
                                &&((min2 <= eilandgrenzen[j][1]) 
                                    && (max2 >= eilandgrenzen[j][1])))
                            {
                                if (eilandgrenzen[j][2] == 0) // eiland ging nog niet 
                                                              // door 0
                                {
                                    if ((((2*Math.PI) - max2) + min2) < (Math.PI))
                                    // nu wel
                                    {
                                        erLooptEenEilandOmDeBootHeen = true;
                                    }
                                }
                                else // eiland ging al wel door 0
                                {
                                    if (!((((2*Math.PI) - max2) + min2) < (Math.PI)))
                                    // maar deze kustlijn niet
                                    {
                                        erLooptEenEilandOmDeBootHeen = true;
                                    }
                                }
                            }
                        }
                        // anders: pas de grenzen aan
                        else
                        {
                            double max2 = Math.max(vorigeHoek, dezeHoek);
                            double min2 = Math.min(vorigeHoek, dezeHoek);
                            
                            if ((((2*Math.PI) - max2) + min2) < (Math.PI))
                            {
                                // deze kustlijn gaat door '0' heen
                                eilandgrenzen[j][2] = 1;
                                
                                if (dezeHoek > Math.PI)
                                {
                                    eilandgrenzen[j][0] = dezeHoek;
                                }
                                else
                                {
                                    eilandgrenzen[j][1] = dezeHoek;
                                }
                            }
                            else
                            {
                                if (dezeHoek < eilandgrenzen[j][0])
                                {
                                    if (dezeHoek < eilandgrenzen[j][1])
                                    {
                                        // schuif het begin op
                                        eilandgrenzen[j][0] = dezeHoek;
                                    }
                                    else
                                    {
                                        // kijk of de lijn door begin heen gaat of 
                                        // door eind

                                        // als hij door het begin heen gaat
                                        if ((min2 <= eilandgrenzen[j][0]) 
                                            && (max2 >= eilandgrenzen[j][0]))
                                        {
                                            // schuif het begin op
                                            eilandgrenzen[j][0] = dezeHoek;
                                        }
                                        else // anders:
                                        {
                                            // schuif het eind op
                                            eilandgrenzen[j][1] = dezeHoek;
                                        }
                                    }
                                }
                                else
                                {
                                    // schuif het eind op
                                    eilandgrenzen[j][1] = dezeHoek;
                                }
                            }
                        }
                    }
                }
                
                // nu zijn van alle eilanden de grenzen bepaald
                
                boolean erLooptEenEilandDoorNul = false;
                boolean eilandActief[] = new boolean[aantalEilanden];
                int aantalEilandenActief = 0;
                
                double laatsteHoek = 0.0;
                
                for (int j = 0; j < aantalEilanden; j++)
                {
                    eilandActief[j] = false;
                    
                    if (eilandgrenzen[j][2] != 0)
                    {
                        erLooptEenEilandDoorNul = true;
                        eilandActief[j] = true;
                        aantalEilandenActief++;
                    }
                }
                
                /*
                    maak een (gesorteerde) lijst met alle eindpunten
                    bepaal de eerstvolgende eilandgrens die je tegenkomt

                    als het een begin is
                    {
                        als het aantal actieve eilanden 0 was
                        {
                            deze hoek - vorige hoek = een stuk zee
                        }
                        zet het eiland op actief
                    }
                    als het een eind is
                    {
                        zet het eiland op niet-actief
                        {
                            als hiermee het aantal actieve eilanden 0 wordt
                            {
                                onthoud deze hoek
                            }
                        }
                    }
                */
                
                Eindpunt[] eindpunten = new Eindpunt[2*aantalEilanden];
                
                for (int j = 0; j < aantalEilanden; j++)
                {
                    eindpunten[(2*j)] = new Eindpunt(j, eilandgrenzen[j][0], "begin");
                    eindpunten[(2*j)+1] = new Eindpunt(j, eilandgrenzen[j][1], "eind");
                }
                
                eindpunten = sorteerEindpunten(eindpunten);
                
                double totaleHoek = 0.0;
                
                for (int j = 0; j < eindpunten.length; j++)
                {
                    // als het een begin is
                    if ((eindpunten[j].getSoort()).equals("begin"))
                    {
                        // als het aantal actieve eilanden 0 was
                        if (aantalEilandenActief == 0)
                        {
                            // deze hoek - vorige hoek = een stuk zee
                            totaleHoek += (eindpunten[j].getHoek() - laatsteHoek);
                        }
                        // zet het eiland op actief
                        eilandActief[eindpunten[j].getEilandnr()] = true;
                        aantalEilandenActief++;
                    }
                    // als het een eind is
                    else
                    {
                        // zet het eiland op niet-actief
                        eilandActief[eindpunten[j].getEilandnr()] = false;
                        aantalEilandenActief--;
                        {
                            // als hiermee het aantal actieve eilanden 0 wordt
                            if (aantalEilandenActief == 0)
                            {
                                // onthoud deze hoek
                                laatsteHoek = eindpunten[j].getHoek();
                            }
                        }
                    }
                }
                
                if (!erLooptEenEilandDoorNul)
                {
                    totaleHoek += ((2*Math.PI) - laatsteHoek);
                }
                
                double resultaat;
                if (erLooptEenEilandOmDeBootHeen)
                {
                    resultaat = 1.0;
                }
                else
                {
                    resultaat = 1 - (totaleHoek / (2 * Math.PI));
                }
                
                // print het resultaat
                System.out.println(stringVanDoubleInlDecimalen(resultaat, 4));
            }
        } catch (IOException e) {System.err.println(e);}

    }
    
    public static double bepaalHoek(Punt hoekpunt, Punt kleineKapiteinPunt)
    {
        double dX = hoekpunt.getX() - kleineKapiteinPunt.getX();
        double dY = hoekpunt.getY() - kleineKapiteinPunt.getY();
        
        double hoek = Math.atan2(dY, dX);
        
        if (hoek < 0)
        {
            return (hoek + 2*Math.PI);
        }
        else
        {
            return hoek;
        }
    }
    
    public static boolean ligtInHetStukWatJeAlGehadHebt(double h, double b, double e, double o) 
    {
        if (o == 0) // je ging nog niet door '0'
        {
            return ((h > b) && (h < e));
        }
        else // je ging dus wel door '0'
        {
            return ((h < e) || (h > b));
        }
    }
    
    public static Eindpunt[] sorteerEindpunten(Eindpunt[] e)
    {
        Vector hoeken = new Vector();
        
        hoeken.addElement(e[0]);
        
        for (int i = 1; i < e.length; i++)
        {
            int insertPositie = 0;
            
            for (int p = 0; p < hoeken.size(); p++)
            {
                if ((e[i].getHoek() > ( (Eindpunt) hoeken.elementAt(p)).getHoek()))
                {
                    insertPositie = p+1;
                }
            }
            hoeken.insertElementAt(e[i], insertPositie);
        }
        
        Eindpunt[] result = new Eindpunt[e.length];
        
        for (int i = 0; i < e.length; i++)
        {
            result[i] = (Eindpunt) hoeken.elementAt(i);
        }
        
        return result;
    }
    public static String stringVanDoubleInlDecimalen(double d, int l)
    {
        String s = "";
        
        d = Math.round(d * Math.pow(10.0, l));
        int i = (int) d;

        int j = i / ((int) Math.pow(10.0, l));

        s = s + j + ".";

        i = i - (j * ((int) Math.pow(10.0, l)));

        String stringI = "" + i;
        while (stringI.length() < l)
        {
            stringI = "0" + stringI;
        }

        s = s + stringI;

        return s;
    }
}

class Punt
{
    double x;
    double y;

    public Punt(double xIn, double yIn)
    {
        x = xIn;
        y = yIn;
    }

    public double getX()
    {
        return x;
    }

    public double getY()
    {
        return y;
    }
}

class Eindpunt
{
    int eilandnummer;
    double hoek;
    String soort;
    
    public Eindpunt(int nr, double h, String srt)
    {
        eilandnummer = nr;
        hoek = h;
        soort = srt;
    }
    
    public int getEilandnr()
    {
        return eilandnummer;
    }
    
    public double getHoek()
    {
        return hoek;
    }
    
    public String getSoort()
    {
        return soort;
    }
}
