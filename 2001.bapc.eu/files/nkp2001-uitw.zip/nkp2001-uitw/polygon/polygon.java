/*
 *  Oplossing voor de opgave "De stranden van Polygonesie".
 *  Joris van Rantwijk, Jun 2001.
 */

import java.io.StreamTokenizer;
import java.io.InputStreamReader;
import java.io.IOException;

class Polygon
{

	static final int MAX_EILAND = 20;
	static final int MAX_HOEKPUNT = 20;
	static final int MAX_COORD = 1000;

	static int n;
	static int[] eilandP;
	static int[][] eilandX, eilandY;
	static int bootX, bootY;

	static int getInt(StreamTokenizer f) throws IOException
	{
		f.nextToken();
		return Integer.parseInt(f.sval);
	}


	static void assert(boolean v)
	{
		if (!v) throw new Error("Assertion failed");
	}


	// Projecteer het gegeven punt op de horizon rondom de boot.
	// Resultaat tussen 0 en 1 (incl).
	static double projectPoint(int x, int y)
	{
		return (Math.atan2(y - bootY, x - bootX) + Math.PI) / (2*Math.PI);
	}


	// Bepaal of het gegeven lijnstuk van links naar rechts loopt
	// vanuit de roeiboot gezien.
	static boolean isLeftToRight(int x1, int y1, int x2, int y2)
	{
		// Boot moet rechts van p1->p2 liggen ...
		return ((y1-y2)*(bootX-x1) + (x2-x1)*(bootY-y1) < 0);
	}


	static double bepaalZichtbareKust()
	{
		double[] spanpoint;
		boolean[] leftpoint;
		int iskust;

		// Tel de hoekpunten van alle eilanden samen.
		int p = 0;
		for (int i = 0; i < n; i++)
			p += eilandP[i];

		// Lijst hoekpunten geprojecteerd op de horizon, met
		// een indicatie of het de linker kant van het strand is.
		spanpoint = new double[2*p];
		leftpoint = new boolean[2*p];

		// Projecteer alle strandsegmenten op de horizon.
		// Tel ook het aantal strandsegmenten dat het 0-punt overdekt.
		iskust = 0;
		int q = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < eilandP[i]; j++) {
				int nj = (j + 1) % eilandP[i];
				spanpoint[q] = projectPoint(eilandX[i][j], eilandY[i][j]);
				spanpoint[q+1] = projectPoint(eilandX[i][nj], eilandY[i][nj]);
				leftpoint[q] = isLeftToRight(eilandX[i][j], eilandY[i][j],
				                             eilandX[i][nj], eilandY[i][nj]);
				leftpoint[q+1] = ! leftpoint[q];
				if ((leftpoint[q] && spanpoint[q] < spanpoint[q+1]) ||
				    (leftpoint[q+1] && spanpoint[q] > spanpoint[q+1]))
					iskust++;
				q += 2;
			}
		}

		// Sorteer de geprojecteerde hoekpunten
		for (int i = 0; i < 2*p; i++) {
			double s = spanpoint[i];
			boolean l = leftpoint[i];
			int j = i;
			while (j > 0 && spanpoint[j-1] > s) {
				spanpoint[j] = spanpoint[j-1];
				leftpoint[j] = leftpoint[j-1];
				j--;
			}
			spanpoint[j] = s;
			leftpoint[j] = l;
		}

		// Scan de horizon en bepaal het overdekte deel.
		double kustlen = 0.0;
		double lastpoint = 0.0;
		for (int i = 0; i < 2*p; i++) {
			if (iskust > 0)
				kustlen += spanpoint[i] - lastpoint;
			iskust += (leftpoint[i]) ? -1 : +1;
			lastpoint = spanpoint[i];
		}
		if (iskust > 0)
			kustlen += 1.0 - lastpoint;

		return kustlen;
	}


	public static void main(String args[])
	{
		try {

			StreamTokenizer f = new StreamTokenizer(
			  new InputStreamReader(System.in));
		
			f.resetSyntax();
			f.whitespaceChars(0, 32);
			f.wordChars(33, 127);

			int runs = getInt(f);

			while ((runs--) > 0) {
				n = getInt(f);
				assert(n >= 1 && n <= MAX_EILAND);

				eilandP = new int[n];
				eilandX = new int[n][];
				eilandY = new int[n][];

				for (int i = 0; i < n; i++) {
					eilandP[i] = getInt(f);
					assert(eilandP[i] >= 3 && eilandP[i] <= MAX_HOEKPUNT);
					eilandX[i] = new int[eilandP[i]];
					eilandY[i] = new int[eilandP[i]];
					for (int j = 0; j < eilandP[i]; j++) {
						eilandX[i][j] = getInt(f);
						eilandY[i][j] = getInt(f);
						assert(eilandX[i][j] >= 0 && eilandX[i][j] <= MAX_COORD &&
						       eilandY[i][j] >= 0 && eilandY[i][j] <= MAX_COORD);
					}
				}

				bootX = getInt(f);
				bootY = getInt(f);
				assert(bootX >= 0 && bootX <= MAX_COORD &&
				       bootY >= 0 && bootY <= MAX_COORD);

				double zk = bepaalZichtbareKust();
				int k = (int) (10000.0 * zk + 0.5);
				assert( (int) (10000.0 * (zk + 0.00001) + 0.5) == k &&
				        (int) (10000.0 * (zk - 0.00001) + 0.5) == k );
				System.out.println((k / 10000) + "." +
				                   ((k/1000)%10) + "" +
						   ((k/100)%10) + "" +
						   ((k/10)%10) + "" +
						   (k%10));
			}

		} catch (IOException e) { System.err.println(e); }
	}

}

/* end */
