/*
 * Uitwerking door Lian Ien Oei - NKP 2001
 *
 * Deze uitwerking werkt met faculteiten.
 *
 * NB: Dit programma kan niet alle input aan!!!
 *     Te grote waarden geven een overflow!!!
 *     Met longs i.p.v. ints werkt het wel.
 */

import java.io.*;
class Spin
{
    public static void main(String[] args)
    {
        // aantal runs 'n'
        int n;

        try
        {
            StreamTokenizer f = new StreamTokenizer(new InputStreamReader(System.in));
            f.resetSyntax();
            f.whitespaceChars(0, 0x20);
            f.wordChars(0x21, 0xff);
            f.nextToken();
            n = Integer.parseInt(f.sval);

            for (int i = 0; i < n; i++)
            {
                // aantal spandraden 's'
                f.nextToken();
                int s = Integer.parseInt(f.sval);

                // aantal tussendraden 't'
                f.nextToken();
                int t = Integer.parseInt(f.sval);

                // positie van de spin
                f.nextToken();
                int a = Integer.parseInt(f.sval);
                f.nextToken();
                int b = Integer.parseInt(f.sval);

                // positie van de vlieg
                f.nextToken();
                int c = Integer.parseInt(f.sval);
                f.nextToken();
                int d = Integer.parseInt(f.sval);

                // alle waarden zijn nu ingelezen

                int aantalRoutes;

                if ((b == 0) || (d == 0)) // de spin of de vlieg zit in het 
                                          // midden van het web
                {
                    aantalRoutes = 1;
                }
                else
                {
                    // het aantal stappen door het middelpunt
                    int MStappen = b + d;

                    // het aantal stappen over een spandraad
                    int SStappen = Math.abs(b - d);

                    // het aantal stappen over een tussendraad
                    int TStappen = Math.min(Math.abs(a - c), s - Math.abs(a - c));

                    // het totaal aantal stappen
                    int SEnTStappen = SStappen + TStappen;

                    // het aantal mogelijke routes
                    int SEnTRoutes =
                        faculteit(SEnTStappen) / (faculteit(SStappen) * faculteit(TStappen));

                    // indien het aantal stappen rechtsom gelijk is aan het
                    // aantal stappen linksom
                    if (Math.abs(a - c) == (s - Math.abs(a - c)))
                    {
                        SEnTRoutes = 2 * SEnTRoutes;
                    }

                    // als de weg door het middelpunt minder stappen kost dan 
                    // over de span- en tussendraden, dan is er slechts 1
                    // kortste route
                    if (MStappen < SEnTStappen)
                    {
                        aantalRoutes = 1;
                    }
                    else if (MStappen == SEnTStappen)
                    {
                        aantalRoutes = SEnTRoutes + 1;
                    }
                    else // MStappen > SEnTStappen
                    {
                        aantalRoutes = SEnTRoutes;
                    }
                }
                System.out.println(aantalRoutes);
            }
        } catch (IOException e) {System.err.println(e);}
    }

    public static int faculteit(int i)
    {
        int result = 1;

        for (int j = 1; j <= i; j++)
        {
            result = result * j;
        }

        return result;
    }
}
