/*
 * Uitwerking door Lian Ien Oei - NKP 2001
 * 
 * Deze uitwerking van "De spin en zijn prooi" werkt volgens:
 * ((n * (n-1) * (n-2) * .... * (max(k, (n-k)) + 1) ) / ((min(k, n-k))!)
 */

import java.io.*;
class Spin3
{
    public static void main(String[] args)
    {
        // aantal runs 'n'
        int n;

        try
        {
            StreamTokenizer f = new StreamTokenizer(new InputStreamReader(System.in));
            f.resetSyntax();
            f.whitespaceChars(0, 0x20);
            f.wordChars(0x21, 0xff);
            f.nextToken();
            n = Integer.parseInt(f.sval);

            for (int i = 0; i < n; i++)
            {
                // aantal spandraden 's'
                f.nextToken();
                int s = Integer.parseInt(f.sval);

                // aantal tussendraden 't'
                f.nextToken();
                int t = Integer.parseInt(f.sval);

                // positie van de spin
                f.nextToken();
                int a = Integer.parseInt(f.sval);
                f.nextToken();
                int b = Integer.parseInt(f.sval);

                // positie van de vlieg
                f.nextToken();
                int c = Integer.parseInt(f.sval);
                f.nextToken();
                int d = Integer.parseInt(f.sval);
                
                // alle waarden zijn nu ingelezen
                
                int aantalRoutes;

                if ((b == 0) || (d == 0)) // de spin of de vlieg zit in het 
                                          // midden van het web
                {
                    aantalRoutes = 1;
                }
                else
                {
                    // het aantal stappen door het middelpunt
                    int MStappen = b + d;
                    
                    // het aantal stappen over een spandraad
                    int SStappen = Math.abs(b - d);
                    
                    // het aantal stappen over een tussendraad
                    int TStappen = Math.min(Math.abs(a - c), s - Math.abs(a - c));
                    
                    // het totaal aantal stappen
                    int SEnTStappen = SStappen + TStappen;
                    
                    // (n! / (k! * (n-k)!)):
                    // als je n! helemaal uit zou werken, zouden de 
                    // tussenwaarden groter worden dan de maximale int-waarde. 
                    // daarom wordt deze waarde eerst 'gedeeld door' 
                    // (max(k, n-k))!, waarmee eigenlijk bedoeld wordt dat 
                    // alleen het product van de grootste termen uitgewerkt 
                    // wordt, dus:
                    // ((n * (n-1) * (n-2) * .... * (max(k, (n-k)) + 1) ) / ((min(k, n-k))!)
                    
                    int maxKNminK = Math.max(SStappen, TStappen); // max(k, n-k)
                    int minKNminK = Math.min(SStappen, TStappen); // min(k, n-k)
                    
                    // het aantal mogelijke routes
                    int SEnTRoutes = 
                        NFaculteitGedeeldDoorMaxKNMinKFaculteit(SEnTStappen, maxKNminK) / faculteit(minKNminK);
                    
                    // indien het aantal stappen rechtsom gelijk is aan het 
                    // aantal stappen linksom
                    if (Math.abs(a - c) == (s - Math.abs(a - c)))
                    {
                        SEnTRoutes = 2 * SEnTRoutes;
                    }

                    // als de weg door het middelpunt minder stappen kost dan 
                    // over de span- en tussendraden, dan is er slechts 
                    // 1 kortste route
                    if (MStappen < SEnTStappen)
                    {
                        aantalRoutes = 1;
                    }
                    else if (MStappen == SEnTStappen)
                    {
                        aantalRoutes = SEnTRoutes + 1;
                    }
                    else // MStappen > SEnTStappen
                    {
                        aantalRoutes = SEnTRoutes;
                    }
                }
                System.out.println(aantalRoutes);
            }
        } catch (IOException e) {System.err.println(e);}
    }
    
    public static int faculteit(int i)
    {
        int result = 1;
        
        for (int j = 1; j <= i; j++)
        {
            result = result * j;
        }
        
        return result;
    }
    
    public static int NFaculteitGedeeldDoorMaxKNMinKFaculteit(int n, int maxknmink)
    {
        int result = 1;
        
        for (int j = n; j > maxknmink; j--)
        {
            result = result * j;
        }
        
        return result;
    }
}
