#include <stdio.h>


// tabel wordt gebruikt voor dynamisch programmeren
int tabel[16][21];


// geeft het aantal mogelijke routes
int stappen (int a, int b) {
  if (a == 0 || b == 0) return 1;
  // Als we deze nog niet weten gaan we 'm eerst berekenen
  if (tabel[a][b] == 0) tabel[a][b] = stappen(a-1,b) + stappen(a,b-1);
  return tabel[a][b];
}


int main (void) {

  // open file a.in
//  FILE* fp = fopen("a.in","r");
  FILE *fp = stdin;

  // een aantal variabelen
  int runs;         // het aantal runs
  int s,t,a,b,c,d;  // de in te lezen variabelen per run
  int x,y,z,v;      // een aantal hulpvariabelen

  fscanf(fp,"%d\n",&runs);

  while ((runs--) > 0) {

    // lees alles in
    fscanf(fp,"%d %d\n%d %d\n%d %d\n",&s,&t,&a,&b,&c,&d);

    // als er een beest in het middelpunt zit is er maar 1 kortste route
    if (b == 0 || d == 0) printf("1\n");
    else {

      // initialiseren van de tabel;
      for (int i = 0; i <= s; i++) {
        for (int j = 0; j <= t; j++) {
          tabel[i][j]=0;
        }
      }

      z = b + d;                  // het aantal te nemen stappen via het middelpunt
      if (a > c) x = a - c;       // nu berekenen we de verschillen in x en y richting
      else x = c - a;
      if (b > d) y = b - d;
      else y = d - b;
      if (s - x < x) x = s - x;   // misschien kunnen we beter andersom lopen
      if (s - x == x) v = 2;      // misschien zijn allebei de kanten op evenveel stappen
      else v = 1;

      if (z < x + y || x == 0) printf("1\n");
      else if (z == x + y) printf("%d\n",1 + v * stappen(x,y));
      else printf("%d\n",v * stappen(x,y));
    }

  }

  return 0;
}
