/*
 * Uitwerking door Lian Ien Oei - NKP 2001
 *
 * Deze uitwerking werkt met een soort kortste-pad-algoritme:
 * Het begint bij de beginpositie en laat de spin elke keer een stap doen, 
 * totdat hij bij de vlieg is aangekomen. Tussendoor wordt steeds bijgehouden 
 * op hoeveel manieren hij op een bepaalde positie kan komen.
 */

import java.io.*;
class Spin2
{
    private static int n, s, t, a, b, c, d;
    private static int alleLocaties[][];
    
    public static void main(String[] args)
    {
        try
        {
            StreamTokenizer f = new StreamTokenizer(new InputStreamReader(System.in));
            f.resetSyntax();
            f.whitespaceChars(0, 0x20);
            f.wordChars(0x21, 0xff);
            f.nextToken();
            // n = aantal runs
            n = Integer.parseInt(f.sval);

            for (int i = 0; i < n; i++)
            {
                // aantal spandraden 's'
                f.nextToken();
                s = Integer.parseInt(f.sval);

                // aantal tussendraden 't'
                f.nextToken();
                t = Integer.parseInt(f.sval);

                // positie van de spin
                f.nextToken();
                a = Integer.parseInt(f.sval); // a = spandraad spin
                f.nextToken();
                b = Integer.parseInt(f.sval); // b = tussendraad spin

                // positie van de vlieg
                f.nextToken();
                c = Integer.parseInt(f.sval); // c = spandraad vlieg
                f.nextToken();
                d = Integer.parseInt(f.sval); // d = tussendraad vlieg
                
                // alle waarden zijn nu ingelezen
                
                // corrigeer de waarden zo, dat het middelpunt slechts op 
                // 1 manier gerepresenteerd wordt, nl. door de waarde (0,0).
                if (b == 0)
                {
                    a = 0;
                }
                if (d == 0)
                {
                    c = 0;
                }
                
                // alleLocaties[][] is een array waarin voor alle mogelijke 
                // posities bijgehouden wordt op hoeveel manieren de spin er 
                // kan komen
                alleLocaties = new int[s + 1][t + 1];
                
                // initialiseer de array en zet de spin op de juiste plek
                initialiseerSpinPositie();
                
                // laat de spin een stap doen, net zolang totdat de vlieg 
                // gepakt is
                while (!vliegGepakt())
                {
                    doeEenStap();
                }
                
                // op de positie van de vlieg staat nu op hoeveel mogelijke 
                // manieren de spin er kan komen
                int aantalRoutes = alleLocaties[c][d];
                
                System.out.println(aantalRoutes);
            }
        } catch (IOException e) {System.err.println(e);}
    }

    // de positie van de spin wordt op 1 gezet, alle overige waarden 
    // in de array worden op 0 geinitialiseerd
    private static void initialiseerSpinPositie()
    {
        for (int i = 0; i < s + 1; i++)
        {
            for (int j = 0; j < t + 1; j++)
            {
                alleLocaties[i][j] = 0;
            }
        }
        alleLocaties[a][b] = 1;
    }
    
    private static boolean vliegGepakt()
    {
        return alleLocaties[c][d] != 0;
    }
    
    private static void doeEenStap()
    {
        // maak een even grote array aan voor de waarden na deze stap
        int[][] nieuweWaarden = new int[s + 1][t + 1];
        
        // vul de array met nieuwe waarden:
        // de nieuwe waarde op een bepaalde positie is de som van de 
        // waarden van alle buur-posities
        nieuweWaarden[0][0] = 0;
        for (int spandraad = 1; spandraad < s + 1; spandraad++)
        {
            // bereken de nieuwe waarde voor het middelpunt
            nieuweWaarden[0][0] = nieuweWaarden[0][0] + alleLocaties[spandraad][1];
            for (int tussendraad = 1; tussendraad < t + 1; tussendraad++)
            {
                int waardeLangsSpandraad = 0;
                int waardeLangsTussendraad = 0;
                
                // bereken waardeLangsTussendraad (== aantal mogelijke routes
                // als deze stap over een tussendraad gezet wordt)
                if (spandraad == 1)
                {
                    waardeLangsTussendraad = alleLocaties[s][tussendraad] + alleLocaties[2][tussendraad];
                }
                else if (spandraad == s)
                {
                    waardeLangsTussendraad = alleLocaties[s - 1][tussendraad] + alleLocaties[1][tussendraad];
                }
                else
                {
                    waardeLangsTussendraad = alleLocaties[spandraad - 1][tussendraad] + alleLocaties[spandraad + 1][tussendraad];
                }
                
                // bereken waardeLangsSpandraad (== aantal mogelijke routes
                // als deze stap over een spandraad gezet wordt)
                if (tussendraad == 1)
                {
                    waardeLangsSpandraad = alleLocaties[0][0];
                    
                    if (t >= 2)
                    {
                        waardeLangsSpandraad = waardeLangsSpandraad + alleLocaties[spandraad][2];
                    }
                }
                else if (tussendraad == t)
                {
                    waardeLangsSpandraad = alleLocaties[spandraad][t - 1];
                }
                else
                {
                    waardeLangsSpandraad = alleLocaties[spandraad][tussendraad - 1] + alleLocaties[spandraad][tussendraad + 1];
                }
                
                nieuweWaarden[spandraad][tussendraad] = waardeLangsSpandraad + waardeLangsTussendraad;
            }
        }
        
        alleLocaties = nieuweWaarden;
    }

}
