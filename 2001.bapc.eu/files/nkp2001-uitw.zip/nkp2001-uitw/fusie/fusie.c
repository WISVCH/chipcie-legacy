#include <stdlib.h>
#include <stdio.h>

#define MAXCOMPANIES 4000

FILE *fin;

struct companynode {
  int number;
  int omzet;
  struct companynode *left;
  struct companynode *right;
};

void printrec(struct companynode *node) {
  if (node->left!=NULL && node->right!=NULL) {
    printrec(node->left);
    printrec(node->right);
  } else 
    printf("%d ",node->number);
}
  
int main(void) {
  int run, i;
  int nrcompanies, merge1, merge2;
  struct companynode *merge1node, *merge2node, *mergenode;
  struct companynode *nodearray[MAXCOMPANIES];
  
  /* fin = fopen("fusie.in", "r"); */
  fin = stdin;
  fscanf(fin, "%d\n", &run);
  while ((run--) > 0) {
    fscanf(fin, "%d\n", &nrcompanies);
    for (i=0;i<nrcompanies;i++) {
      nodearray[i] = (struct companynode *) malloc(sizeof(struct companynode));
      nodearray[i]->number = i+1;
      nodearray[i]->left = NULL;
      nodearray[i]->right = NULL;
      fscanf(fin, "%d\n", &nodearray[i]->omzet);
    }
    mergenode = nodearray[0];
    for (i=0;i<nrcompanies-1;i++) {
      fscanf(fin, "%d %d\n", &merge1, &merge2);
      merge1node = nodearray[merge1-1];
      merge2node = nodearray[merge2-1];
      mergenode = (struct companynode *) malloc(sizeof(struct companynode));
      mergenode->number = (merge1node->number<merge2node->number)?merge1node->number:merge2node->number;
      mergenode->omzet = merge1node->omzet + merge2node->omzet;
      mergenode->left = (merge1node->omzet>merge2node->omzet)?merge1node:merge2node;
      mergenode->right =(merge1node->omzet<merge2node->omzet)?merge1node:merge2node;
      nodearray[mergenode->number-1] = mergenode;
    }
    printrec(mergenode);
    printf("\n");
  }
  fclose(fin);
  return 0;
}
