import java.io.StreamTokenizer;
import java.io.InputStreamReader;
import java.io.IOException;

public class BinaireCodes {
    
    
    public static void main (String args[]) {
        new BinaireCodes();
    }
    
    
    double[][] dyn = new double[101][101];
    
    
    public BinaireCodes () {
        int opl, opl2;
        String oplstr;

	try {

        StreamTokenizer tok = new StreamTokenizer(new InputStreamReader(System.in));
        tok.resetSyntax();
        tok.whitespaceChars(0, 32);
        tok.wordChars(33, 127);

        tok.nextToken();
        int runs = Integer.parseInt(tok.sval);

        while ((runs--) > 0) {

            tok.nextToken();
	    int i = Integer.parseInt(tok.sval);

            if (i == 2) { System.out.println("2^0.000"); continue; }

            // Er wordt hieronder flink gehannest om de oplossing correct af te ronden en in de goede vorm te printen.
            opl = (int)(( Math.log(go(i,1)) / Math.log(2) ) * 10000);
            opl2 = opl / 10;
            if (opl % 10 > 4) opl2++;
            oplstr = "" + opl2;
            System.out.println("2^" + oplstr.substring(0,oplstr.length()-3) + "." + oplstr.substring(oplstr.length()-3,oplstr.length()));
        }

	} catch (IOException e) { System.err.println(e); }

    }
    
    
    private double go (int a, int b) {
        if (dyn[a][b] != 0) return dyn[a][b];
        else if (a == b) return 1;
        else if (b == 1) return go(a,2);
        else {
            int og = 1;
            int bg = b - 1;
            double res = 0;
            if (2 * b > a) og = 2 * b - a;
            else res = go(a,2*b);
            for (; og <= bg; og++) res += boven(a,og) * go(a - og, 2 * (b - og));
            dyn[a][b] = res;
            return res;
        }
    }
    
    
    private double boven (int a, int b) {
        double res = a;
        if (b == 1 || a - b == 1) return res;
        int c;
        if (a >= 2 * b) c = a - b;
        else { c = b; b = a - b; }
        a--;
        while (a > b) { res *= a; a--; }
        while (c > 1) { res /= c; c--; }
        return res;
    }
    
}
