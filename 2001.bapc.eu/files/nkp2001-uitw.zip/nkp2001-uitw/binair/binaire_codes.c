#include <math.h>
#include <stdio.h>

double binomial(int n, int m)
{
  double b;
  int i;
  b = 1;
  for(i=1;i<=m;i++)
    {
      b*=(n-m+i);
      b/=i;
    }
  return b;
}

#define RSIZE 101

double remember[RSIZE][RSIZE];

double count(int S, int B)
{

  if (B >S) return 0.0;
  if (B==S) return 1.0;
  if (B==0) return 0.0;

  if (remember[S][B]==-1.0)
    {
      int i;
      for(remember[S][B]=i=0;i<=B;i++)
	remember[S][B] += binomial(S,i) * count((S-i),(B-i)*2);
    }
  return remember[S][B];
}

int main(void)

{
  int i,j;

  for(i=0;i<RSIZE;i++)
    for(j=0;j<RSIZE;j++)
      remember[i][j]=-1.0;

  scanf("%d",&i);
  while(i--)
    {
      scanf("%d",&j);
      printf("2^%.3f\n",log(count(j,1))/log(2.0));
    }

  return 0;
}
