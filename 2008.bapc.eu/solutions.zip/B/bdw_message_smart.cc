#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>

using namespace std;

#define FOR(i,a,b) for(int i=(a); i<(b); ++i)
#define REP(i,n) FOR(i,0,n)

#define MAXC 30
#define MAXL 300

//#define ERRPROB_REVERSE
//#define PRINT_MINDIF

int rchars[256];
char chars[MAXC];
int numchars;

double errprob[MAXC][MAXC];
double lingprob[MAXC][MAXC];
int recvmess[MAXL];
int messlen;

int prev[MAXL][MAXC];
double chance1[MAXC], chance2[MAXC];

char bestmess[MAXL+1];

double mindiff;
double mindifpos;

void recurs() {

	mindiff = 1e9;

	// first step

	double *chance = chance1, *prevchance = chance2;

	REP(i,numchars) {

#ifdef ERRPROB_REVERSE
		chance[i] = errprob[recvmess[0]][i];
#else
		chance[i] = errprob[i][recvmess[0]];
#endif

		prev[0][i] = -1;
	}

	FOR(i,1,messlen) {

		double *tmp = chance;
		chance = prevchance;
		prevchance = tmp;

		REP(k,numchars) {
			chance[k] = 1.0;
			prev[i][k] = -1;
		}

		int curchr = recvmess[i];

		REP(a,numchars) REP(b,numchars) {
#ifdef ERRPROB_REVERSE
			double prob = prevchance[a] + lingprob[a][b] + errprob[curchr][b];
			if( prevchance[a] > 0 || lingprob[a][b] > 0 || errprob[curchr][b] > 0 ) continue;
#else
			double prob = prevchance[a] + lingprob[a][b] + errprob[b][curchr];
			if( prevchance[a] > 0 || lingprob[a][b] > 0 || errprob[b][curchr] > 0 ) continue;
#endif
			if( chance[b] > 0 || prob > chance[b] ) {
				if( chance[b] <= 0 ) {
					double diff = fabs(chance[b]-prob);
					if( diff < mindiff ) {
						mindiff = diff;
						mindifpos = (double)(i+1)/(double)messlen;
					}
				}
				chance[b] = prob;
				prev[i][b] = a;
			}
		}
	}

	int node = -1;
	double prob = 1.0;

	REP(i,numchars) {
		if( prob > 0 || (chance[i] > prob && chance[i] <= 0) ) {
			prob = chance[i];
			node = i;
		}
	}

	if( prob > 0 ) {
		fprintf(stderr, "BLORK! No best node.\n");
		exit(1);
	}

	int ans[messlen];
	int idx = messlen;

	ans[--idx] = node;

	while( idx > 0 ) {

		node = prev[idx][node];

		if( node == -1 ) {
			fprintf(stderr, "BLORK\n");
			exit(1);
		}

		ans[--idx] = node;
	}

	REP(i,messlen) bestmess[i] = chars[ans[i]];

	bestmess[messlen] = 0;

#ifdef PRINT_MINDIF
	printf(" %.10lf %.3lf ", mindiff, mindifpos);
#endif
}

void run() {

	scanf("%d", &numchars);

	REP(i,numchars) {

		unsigned char c_str[2];

		scanf("%s", c_str);

		unsigned char c = c_str[0];

		rchars[c] = i;

		chars[i] = c;
	}

	REP(i,numchars) REP(j,numchars) {
	
		double p;
	
		scanf("%lf", &p);
		
		if( p > 0 ) {

			errprob[i][j] = log(p);

		} else {

			errprob[i][j] = 1.0;
		}
	}

	REP(i,numchars) REP(j,numchars) {
	
		double p;

		scanf("%lf", &p);
		
		if( p > 0 ) {

			lingprob[i][j] = log(p);

		} else {

			lingprob[i][j] = 1.0;
		}
	}

	int n; scanf("%d", &n);

	REP(i,n) {

		unsigned char msg[MAXL+1];

		scanf("%s", msg);

		messlen = strlen((char *)msg);

		REP(i,messlen) recvmess[i] = rchars[msg[i]];

		strcpy(bestmess, "ERR");

		recurs();

		puts(bestmess);
	}
}

int main() {
	int n; scanf("%d", &n);
	REP(i,n) run();
	return 0;
}
