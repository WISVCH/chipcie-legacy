#include <cstdio>
#include <vector>
#include <map>
#include <cmath>
#include <algorithm>

//#define MAKEPICTURES

using namespace std;

#define PB push_back
#define SZ(v) ((int)(v).size())
#define FOR(i,a,b) for(int i=(a);i<int(b);++i)
#define REP(i,n) FOR(i,0,n)
#define FORE(i,a,b) for(int i=(a);i<=int(b);++i)
#define REPE(i,n) FORE(i,0,n)
#define FORSZ(i,a,v) FOR(i,a,SZ(v))
#define REPSZ(i,v) FORSZ(i,0,v)
#define VAR(a,b) __typeof(b) a=b
#define FORIT(it,v) for(VAR(it,(v).begin());it!=(v).end();++(it))
#define ALL(v) (v).begin(),(v).end()
#define SORT(v) sort(ALL(v))
#define ABS(x) ((x) < 0 ? -(x) : (x))

typedef struct { int x, y; } P;
typedef vector<P> VP;

int triarea(P a, P b, P c) { return a.x*b.y - b.x*a.y + b.x*c.y - c.x*b.y + c.x*a.y - a.x*c.y; }

P pivot;

bool operator<(const P &a, const P &b) {
	int r = triarea(pivot, a, b);
	if (r != 0) {
		return r > 0;
	}
	return ABS(pivot.x - a.x) < ABS(pivot.x - b.x) ||
	    ABS(pivot.y - a.y) < ABS(pivot.y - b.y);
}

bool operator==(const P &a, const P &b) {
	return a.x == b.x && a.y == b.y;
}

bool operator!=(const P &a, const P &b) {
	return a.x != b.x || a.y != b.y;
}

VP convexhull(VP in) {
	VP out;
	VP::iterator p;

	p = in.end();
	FORIT(it, in) {
		if (p == in.end() || it->x < p->x ||
		    (it->x == p->x && it->y < p->y)) {
			p = it;
		}
	}
	pivot = *p;
	out.PB(pivot);
	in.erase(p);
	SORT(in);

	FORIT(it, in) {
		int outsz = SZ(out);
		while (outsz > 1 &&
		    triarea(out[outsz - 2], out[outsz - 1], *it) <= 0) {
			out.pop_back();
			outsz--;
		}
		out.PB(*it);
	}

	return out;
}


void write_picture(const VP &p, const VP &hull) {

	static int num;
	char filename[100];
	sprintf(filename, "pictures/case%02d.eps", ++num);

	FILE *f = fopen(filename, "wt");
	if( !f ) return;

	int minx = 1000, miny = 1000, maxx = -1000, maxy = -1000;

	REPSZ(k,hull) {
		if( hull[k].x < minx ) minx = hull[k].x;
		if( hull[k].x > maxx ) maxx = hull[k].x;
		if( hull[k].y < miny ) miny = hull[k].y;
		if( hull[k].y > maxy ) maxy = hull[k].y;
	}

	minx -= 5; miny -= 5; maxx += 5; maxy += 5;

	fputs("%!PS-Adobe-3.0 EPSF-3.0\n", f);
	fprintf(f, "%%%%BoundingBox: %d %d %d %d\n", minx, miny, maxx, maxy);
	fputs("%%EndComments\n\n", f);

	// draw the P path first
	
	fputs("newpath\n", f);
	REPSZ(i,p) {
		fprintf(f, "%d %d %s\n", p[i].x, p[i].y, (i == 0) ? "moveto" : "lineto");
	}
	fputs("closepath\n", f);
	fputs("gsave\n", f);
	fputs("1.0 0.3 0.3 setrgbcolor\n", f);
	fputs("fill\n", f);


	fputs("newpath\n", f);
	REPSZ(i,hull) {
		fprintf(f, "%d %d %s\n", hull[i].x, hull[i].y, (i == 0) ? "moveto" : "lineto");
	}
	fputs("closepath\n", f);
	fputs("0.0 0.0 1.0 setrgbcolor\n", f);
	fputs("0.4 setlinewidth\n", f);
	fputs("stroke\n", f);

	fputs("grestore\n", f);
	fputs("0.2 setgray\n", f);
	fputs("0.2 setlinewidth\n", f);
	fputs("stroke\n", f);

	fclose(f);
}


void solve() {
	
	int cost, profit; scanf("%d%d", &cost, &profit);
	int n; scanf("%d", &n);
	VP p(n);
	REP(i,n) scanf("%d%d", &p[n-1-i].x, &p[n-1-i].y);
	REP(a,n) FOR(b,a+1,n) FOR(c,b+1,n) {
		int dx1 = p[a].x - p[b].x;
		int dx2 = p[b].x - p[c].x;
		int dy1 = p[a].y - p[b].y;
		int dy2 = p[b].y - p[c].y;
		if( dx1 * dy2 == dx2 * dy1 ) {
			fprintf(stderr, "trilinear points %d %d %d\n",
				n-a,n-b,n-c);
		}
	}
	VP hull = convexhull(p);
#ifdef MAKEPICTURES
	write_picture(p,hull);
#endif
	int k = -1;
	REPSZ(i,p) {
		if( p[i] == hull[0] ) {
			k = i;
			break;
		}
	}
	int score = profit * SZ(hull);
	int nicks = 0;
	hull.PB(*hull.begin());
	REPSZ(i,hull) {
		if( p[k] != hull[i] ) {
			++nicks;
			score -= cost + profit;
			while( p[k] != hull[i] ) {
				++k; k %= SZ(p);
			}
		}
		++k; k %= SZ(p);
	}
	printf("%d\n", max(0,score));
}

int main()
{
	int n; scanf("%d", &n);
	REP(i,n) solve();
}

