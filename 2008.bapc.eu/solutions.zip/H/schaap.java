import java.io.*;
import java.util.*;

class ProblemH {
    static Scanner s;
    static double pi;

    public static void main( String[] args ) {
        try {
            if( args.length > 0 )
                s = new Scanner( new FileInputStream( args[0] ) );
            else
                s = new Scanner( new FileInputStream( "h.in" ) );
            int n = s.nextInt( );
            pi = Math.PI;
            while( n-- > 0 )
                doTestCase( );
        }
        catch( Exception e ) {
            throw new RuntimeException( e );
        }
    }

    static int[] x = new int[100];
    static int[] y = new int[100];
    static int[] nickvertex = new int[101];

    static void doTestCase( ) {
        int q = 0;
        int p = 0;
        int v = 0;
        int i, j, k;
        int dx, dy;
        int innick;
        int nsurfaces;
        int nnicks;
        double myangle;
        int maxY = -1001;
        int nMaxY = -1;
        double angle;
        p = s.nextInt( );
        q = s.nextInt( );
        v = s.nextInt( );
        for( i = 0; i < v; i++ ) {
            x[i] = s.nextInt( );
            y[i] = s.nextInt( );
            if( y[i] > maxY ) {
                maxY = y[i];
                nMaxY = i;
            }
            nickvertex[i] = 1;
        }
        i = nMaxY;
        myangle = 0.0;
        double maxAngle;
        int nMaxAngle;
        // Build convex hull (or actually: note which vertices are on the hull and which in a nick)
        do {
            nickvertex[i] = 0;
            maxAngle = -1.0;
            nMaxAngle = -1;
            for( j = 0; j < v; j++ ) {
                if( j == i )
                    continue;
                angle = calculateAngle( i, j, myangle );
                if( angle > maxAngle ) {
                    maxAngle = angle;
                    nMaxAngle = j;
                }
            }
            myangle += 2*pi - maxAngle;
            i = nMaxAngle;
        } while( i != nMaxY );
        nickvertex[v] = nickvertex[0];
        nsurfaces = 0;
        nnicks = 0;
        innick = 0;
        for( i = 0; i < v; i++ ) {
            if( nickvertex[i] == 0 && nickvertex[i+1] == 0 ) {
                nsurfaces++;
                innick = 0;
            }
            else if( nickvertex[i] == 0 && innick == 0 ) {
                nnicks++;
                innick = 1;
            }
            else if( nickvertex[i] == 0 && innick != 0 ) {
                if( nickvertex[i+1] != 0 ) {
                    nnicks++;
                }
                else {
                    innick = 0;
                }
            }
            else if( nickvertex[i] != 0 && innick == 0 ) { // Can only happen on the first!
                innick = 1;
            }
            // Ignore vertices in the nick
        }
        if( q * nsurfaces > p * nnicks )
            System.out.printf( "%d\n", q*nsurfaces - p*nnicks );
        else
            System.out.printf( "0\n" );
    }

    static double calculateAngle( int from, int to, double up ) {
        int dx = x[to]-x[from];
        int dy = y[to]-y[from];
        double angle;
        if( dy == 0 ) {
            if( dx > 0 ) {
                angle = 0.5*pi;
            }
            else {
                angle = 1.5*pi;
            }
        }
        else {
            angle = Math.atan( (double)dx / (double)dy );
        }
        if( dy < 0 )
            angle += pi;
        if( angle < 0 )
            angle += 2 * pi;
        angle += up;
        while( angle > 2 * pi )
            angle -= 2 * pi;
        return angle;
    }
}
