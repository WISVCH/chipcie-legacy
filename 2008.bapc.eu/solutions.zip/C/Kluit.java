/*
   Solution in Java
   for the problem Skatepark
   for BAPC 2008
   October 2008
*/

import java.io.*;
import java.util.*;
class ProblemC{

    private static String infile = "c.in";

    public static void main(String args []){
        Locale.setDefault( Locale.ENGLISH );
       InputStream is = null;
       try{
            if( args.length > 0 )
                is = new FileInputStream( args[0] );
            else
               is = new FileInputStream(infile) ;
       }
       catch (IOException iox){
            System.err.println(iox.toString());
       }
       Scanner ir = new Scanner(is);
       int cases = ir.nextInt();
       for (int k = 0; k < cases; k++){
          Skatepark sp = new Skatepark(ir);
          sp.solve();
          System.out.println(sp.getSolution());
      }
    }
}

class Skatepark{
   
   int noOfRamps;
   Ramp [] maxRamps;
   Ramp [] minRamps;

   double squareSum;
   double max2sum = 0;
   double min2sum = 0;

   double smallDifference;
   double bigDifference;
   public Skatepark(Scanner sc){
      noOfRamps = sc.nextInt();
      if (noOfRamps > 100000 || noOfRamps < 2)
         alarm("Number of ramps out of range: " + noOfRamps);
      maxRamps = new Ramp [noOfRamps];
      minRamps = new Ramp [noOfRamps];

      squareSum = 0.5 * sc.nextInt();
      if (squareSum > 100000000)
         alarm("Cubic meters out of range: " + 2 * squareSum);
      for (int k = 0; k < noOfRamps; k++){
         double min = sc.nextDouble();
         double max = sc.nextDouble();
         Ramp ramp = new Ramp(min, max);
         maxRamps[k] = ramp;
         minRamps[k] = ramp;
         max2sum += max * max;
         min2sum += min * min;
      }

      Arrays.sort(maxRamps, new MaxOrder());
      Arrays.sort(minRamps, new MinOrder());
   }

   public void solve(){
      smallDifference = calcSmallDifference();
      bigDifference   = calcBigDifference();
   }

   public String getSolution(){
      return format(smallDifference) + " " + format(bigDifference);
   }

   private String format (double d){
      double d100 = 100 * d;
      long rounded = Math.round(d100);
      int heel = (int) (rounded / 100);
      int deel = (int)(rounded % 100);
      String sdeel = "" +deel;
      if (deel < 10)
         sdeel = "0" + deel;
      return heel + "." + sdeel;
   }

   private double difference(Ramp maxmaxRamp, Ramp minminRamp){
      double allBut;

      double minmin = minminRamp.min;
      double minmax = minminRamp.max;
      allBut = max2sum - minmax * minmax;
      if (allBut + minmin * minmin < squareSum)
         minmin = Math.sqrt(squareSum - allBut);

      double maxmax = maxmaxRamp.max;
      double maxmin = maxmaxRamp.min;
      allBut = min2sum - maxmin * maxmin;
      if (allBut + maxmax * maxmax > squareSum)
         maxmax = Math.sqrt(squareSum - allBut);

      return maxmax - minmin;
   }

   private double calcBigDifference(){
      Ramp maxmaxRamp = maxRamps[0];
      Ramp minminRamp = minRamps[0];
      if (maxmaxRamp != minminRamp)
         return difference (maxmaxRamp, minminRamp);
      else{
         Ramp maxmaxRamp2 = maxRamps[1];
         Ramp minminRamp2 = minRamps[1];
         double kand1 = difference(maxmaxRamp2, minminRamp);
         double kand2 = difference(maxmaxRamp, minminRamp2);
         return Math.max(kand1,kand2);
      }
   }

   private double calcSmallDifference(){
     double av2 = squareSum/noOfRamps;
     double av = Math.sqrt(av2);
     double lomax = maxRamps[noOfRamps -1].max;
     double himin = minRamps[noOfRamps -1].min;
     if (lomax >=av && himin <= av)
        return 0;
        
     double restsom = squareSum;
     int rest = noOfRamps;
     int maxindex = noOfRamps - 1;
     double currentMax = maxRamps[maxindex].max;
     while (av > currentMax){
        restsom -= currentMax * currentMax;
        rest--;
        av2 = restsom/ rest;
        av = Math.sqrt(av2);
        maxindex--;
        currentMax = maxRamps[maxindex].max;
     }
     double boven = Math.max(himin, av);

     restsom = squareSum;
     rest = noOfRamps;
     int minindex = noOfRamps - 1;
     double currentMin = minRamps[minindex].min;
     while (av < currentMin){
         restsom -= currentMin * currentMin;
         rest--;
         av2 = restsom / rest;
         av = Math.sqrt(av2);
         minindex--;
         currentMin = minRamps[minindex].min;
     }
     double onder = Math.min(lomax, av);

     return boven - onder;
   }

   private void dump(){
      for (int k = 0; k < noOfRamps; k++)
         System.out.print( maxRamps[k]);
      System.out.println();
      for (int k = 0; k < noOfRamps; k++)
         System.out.print( minRamps[k]);
      System.out.println();
   }

   private void alarm(String reden){
       throw new RuntimeException(reden);
   }
}

class Ramp{
   double min, max;

   public Ramp(double mi, double ma){
      min = mi;
      max = ma;
   }

   public String toString(){
      return "(" + min + ", " + max + ")";
   }   

}

class MaxOrder implements Comparator<Ramp>{
     // grootste eerst
    public int compare(Ramp r1, Ramp r2){
       if (r1.max > r2.max)
          return -1;
       else if (r1.max == r2.max)
          return 0;
       else // r1.max < r2.max
          return 1;
    }
}

class MinOrder implements Comparator<Ramp>{
    // kleinste eerst
    public int compare(Ramp r1, Ramp r2){
       if (r1.min < r2.min)
          return -1;
       else if (r1.min == r2.min)
          return 0;
       else // r1.min > r2.min
          return 1;
    }
}
