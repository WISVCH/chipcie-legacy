import java.util.Scanner;
import java.io.File;
import java.io.PrintStream;

import java.util.Collection;
import java.util.Collections;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Comparator;
import java.util.Arrays;

/**
 * Solver for problem 15: "Song Contest".
 * 
 */
class ProblemA extends AB_ProblemSolver{
	
	public final static char POLITICAL = 'p';
	public final static char QUALITY = 'q';
	
	public static void main(String[] args) throws Exception {
		ProblemA solver = new ProblemA(args);
		solver.run();
	}	
	
	public ProblemA(String[] args){
		super(args);
	}
	
	public void runCase() throws Exception{
		int num_nations = this.in.nextInt(); this.in.nextLine();
		if(num_nations > 100 || num_nations < 1){
			throw new RuntimeException("EPIC FAIL! number of nations too large or too small");
		}
		HashMap<String, AB_Nation> nations = new HashMap<String, AB_Nation>(num_nations);
		
		for (int i = 0; i < num_nations; i++){
			String nation_name = this.in.next();
			char nation_votingBehaviour = this.in.nextLine().trim().charAt(0); 
			if(!(nation_votingBehaviour == 'p' || nation_votingBehaviour == 'q')){
				throw new RuntimeException("EPIC FAIL! undefined voting behaviour");
			}
			
			int nation_x = this.in.nextInt();
			int nation_y = this.in.nextInt();
			int nation_quality = this.in.nextInt(); this.in.nextLine();
			
			if(Math.abs(nation_x) > 10000){
				throw new RuntimeException("EPIC FAIL! x-coordinate out of bounds");
			}
			if(Math.abs(nation_y) > 10000){
				throw new RuntimeException("EPIC FAIL! y-coordinate out of bounds");
			}
			if(nation_quality < 1 || nation_quality > num_nations){
				throw new RuntimeException("EPIC FAIL! quality ranking out of bounds");
			}
			
			AB_Nation nation = new AB_Nation(nation_name, nation_votingBehaviour, nation_x, nation_y, nation_quality);
			nations.put(nation_name, nation);
		}
		
		int num_ranks = this.in.nextInt(); this.in.nextLine();
		if(num_ranks > num_nations - 1 || num_ranks < 1){
			throw new RuntimeException("EPIC FAIL! number of ranked nations out of bounds");
		}
		String wanted_nation_name = this.in.nextLine().trim();
		AB_Nation wanted_nation = nations.get(wanted_nation_name);
		if(wanted_nation == null){
			throw new RuntimeException("EPIC FAIL! wanted nation does not exist");
		}
		
		// Ranks are numbered r (highest) to r-(s-1)+1 (lowest)
		ArrayList<Integer> ranks_political = new ArrayList<Integer>();
		ArrayList<Integer> ranks_quality = new ArrayList<Integer>();
		int base_score = 0;
		
		for(AB_Nation voting_nation: nations.values()){
			if(voting_nation.equals(wanted_nation)) {
				continue;
			}
			
			ArrayList<AB_Nation> nations_to_rank = new ArrayList<AB_Nation>(nations.values());
			nations_to_rank.remove(voting_nation);
			
			Comparator<AB_Nation> comp;
			if(voting_nation.votingBehaviour == QUALITY){
				comp = new AB_QualityComparator();
			}else{
				comp = new AB_PoliticalComparator(voting_nation);
			}
			
			Collections.sort(nations_to_rank, comp);
			this.debug("Ranks of nation " + voting_nation + " [" + voting_nation.votingBehaviour + "]");
			this.debugList(nations_to_rank);
			
			int rank = num_ranks;
			for(AB_Nation ranked_nation: nations_to_rank){
				if(ranked_nation.equals(wanted_nation)){
					break; // found
				}
				rank--;
			}
			
			if(voting_nation.votingBehaviour == QUALITY){
				ranks_quality.add(rank);
			}else{
				ranks_political.add(rank);
			}
			base_score += Math.max(0, rank);
		}
		this.debug("---");
		this.debug("Base score: " + base_score);
		Collections.sort(ranks_political, Collections.reverseOrder());
		this.debug("Quality scores: ");
		this.debugList(ranks_quality);
		this.debug("Political scores: ");
		this.debugList(ranks_political);		
		
		int min_points = Math.max(0, 2+num_ranks-num_nations);
		this.debug("Min points: " + min_points);
		this.debug("---");
		
		int[] netto_per_changed_part = new int[num_nations - 1];
		for(int changed_parts = 0; changed_parts < num_nations - 1; changed_parts++){
			int total_penalty = 0;
			int total_improvement = 0;
			
			int parts_left = changed_parts + 1;
			for(int rank_political: ranks_political){
				if(rank_political + parts_left > min_points){
					int parts_needed = Math.min(parts_left, num_ranks - rank_political);
					total_improvement += Math.min(parts_needed, Math.max(rank_political + parts_needed, min_points));
					parts_left -= parts_needed;
				}
			}
			
			for(int rank_quality: ranks_quality){
				total_penalty += Math.max(0, Math.min(rank_quality - min_points, (changed_parts + 1)));
			}
	
			netto_per_changed_part[changed_parts] = total_improvement - total_penalty;
			this.debug("Changes: " + (changed_parts + 1) + ", imp: " + total_improvement + ", pen: " + total_penalty);
		}
		
		Arrays.sort(netto_per_changed_part);
		int best_improvement = netto_per_changed_part[num_nations - 2];
		best_improvement = Math.max(0, best_improvement);
		int best_score = base_score + best_improvement;
		this.out.println(best_score);
	}
}

class AB_Nation{
	public String name;
	public char votingBehaviour;
	public int quality;
	public int capital_x;
	public int capital_y;
	
	public AB_Nation(String name, char votingBehaviour, int capital_x, int capital_y, int quality){
		this.name = name;
		this.votingBehaviour = votingBehaviour;
		this.quality = quality;
		this.capital_x = capital_x;
		this.capital_y = capital_y;
	}
	
	public double distance(AB_Nation other){
		double dist_x = (double) this.capital_x - other.capital_x;
		double dist_y = (double) this.capital_y - other.capital_y;
		return Math.sqrt(dist_x*dist_x + dist_y*dist_y);
	}
	
	public boolean equals(AB_Nation other){
		return this.name.equals(other.name);
	}
	
	public String toString(){
		return this.name;
	}
}

class AB_PoliticalComparator implements Comparator<AB_Nation>{
	public AB_Nation votingNation;
	
	public AB_PoliticalComparator(AB_Nation votingNation){
		this.votingNation = votingNation;
	}
	
	public int compare(AB_Nation o1, AB_Nation o2){
		double dist_1 = this.votingNation.distance(o1);
		double dist_2 = this.votingNation.distance(o2);
		int returnval =  (int) Math.signum(dist_1 - dist_2);
		
		if(returnval == 0){
			throw new RuntimeException("EPIC FAIL! Nations shouldn't be ranked equally by distance");
		}
		
		return returnval;
	}
}

class AB_QualityComparator implements Comparator<AB_Nation>{

	public int compare(AB_Nation o1, AB_Nation o2){
		int returnval =  (int) Math.signum(o1.quality - o2.quality);
				
		if(returnval == 0){
			throw new RuntimeException("EPIC FAIL! Nations shouldn't be ranked equally by quality");
		}
		
		return returnval;
	}
}

/**
 * Quick-'n-dirty framework to simplify some common tasks
 */
abstract class AB_ProblemSolver{	
	protected Scanner in;
	protected PrintStream out;
	protected PrintStream err;
	
	/**
	 * For quickly switching between showing or hiding debug output
	 */
	protected boolean DEBUG = false;
	
	/**
	 * Default input file, can be overridden by first command line argument
	 */
	protected String default_infile = "a.in";

	public AB_ProblemSolver(String[] args){
		String infile;
		if(args.length > 0){
			infile = args[0];
		}else{
			infile = this.default_infile;
		}
		
		try{
			this.in = new Scanner(new File(infile));
			this.out = System.out;
			this.err = System.err;
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void run() throws Exception{
		int num_cases = this.in.nextInt();
		this.in.nextLine();
		
		for(int i = 0; i < num_cases; i++){
			this.debug("\r\n=== Testcase " + i + " === ");
			this.runCase();
		}
	}
	
	protected abstract void runCase() throws Exception;
	
	/**
	 * Only outputs text (to stderr) when DEBUG is set to true
	 */
	protected void debug(String str){
		if(DEBUG){
			this.err.println(str);
		}
	}
	
	protected void debug(int i){
		this.debug(String.valueOf(i));
	}
	
	protected void debugList(ArrayList list){
		if(DEBUG){
			int s = list.size(); 
			
			this.err.print("[");
			for(int i = 0; i < s; i++){
				this.err.print(list.get(i).toString());
				
				if(i != s-1){
					this.err.print(",");
				}
			}
			this.err.println("]");
		}
	}
	
	protected void debugMatrix(int[][] matrix){
		if(DEBUG){
			for(int i = 0; i < matrix.length; i++){
				for(int j = 0; j < matrix[i].length; j++){
					String element = String.valueOf(matrix[i][j]);
					element = "     ".substring(element.length()) + element;
					this.err.print(element);
				}
				this.err.println();
			}
		}
	}
}
