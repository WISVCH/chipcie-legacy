import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

class ProblemA {

	static Scanner scanner;
	
	public static void main(String[] args) {
            if( args.length > 0 )
	        processInput(args[0]);
	    else
	    	processInput(null);
	}
	
	public static void processInput( String fileName ){
		if( fileName == null ){
			fileName = "a.in";
		}
		File inputFile = new File(fileName);
		try {
			scanner = new Scanner(inputFile);
			int testCaseCount = scanner.nextInt();
			for( int i = 1; i <= testCaseCount; i++ ) {
				processTestCase();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("unchecked")
	public static void processTestCase(){
		int nationCount = scanner.nextInt();
		// make list containing all nations, ranked according to quality
		RankingList qualityRanking = new RankingList(nationCount);
		
		// in additional lists, book-keep political and quality nations
		List<Nation> politicalNations = new ArrayList<Nation>();
		List<Nation> qualityNations = new ArrayList<Nation>();
		
		for( int i = 1; i <= nationCount; i++ ) {
			String nationName = scanner.next();
			String votingStyleString = scanner.next();
			char votingStyle = votingStyleString.charAt(0);
			int nationX = scanner.nextInt();
			int nationY = scanner.nextInt();
			int nationRank = scanner.nextInt();
			Nation currentNation = new Nation( nationName, new Location(nationX, nationY), nationRank, votingStyle );
			if( currentNation.votingStyle == VotingStyle.POLITICAL){
				politicalNations.add( currentNation );
			}
			else if( currentNation.votingStyle == VotingStyle.QUALITY){
				qualityNations.add( currentNation );
			}
			
			qualityRanking.set(nationRank-1, currentNation);
		}
		
		int maxPoints = scanner.nextInt();
		String wantedNationName = scanner.next();
		Nation wantedNation = null;
		
		// now iterate over all nations (we can use qualityRanking for that)
		for(int i = 0; i < nationCount; i++){
			Nation currentNation = qualityRanking.get(i);
			if( wantedNationName.equals(currentNation.getName())){
				wantedNation = currentNation;
			}
			RankingList currentRankingList = new RankingList(nationCount - 1);
			
			if( currentNation.votingStyle == VotingStyle.POLITICAL ){
				// sort according to distance 
				Nation[] nationList = qualityRanking.getList().clone();
				PoliticalComparator comp = new PoliticalComparator(currentNation);
				Arrays.sort( nationList, comp );
				
				// don't include yourself (you should be at position 0 with 0 distance)
				for( int j = 1; j < nationCount; j++ ){
					currentRankingList.set(j-1, nationList[j]);
				}
			}
			else if( currentNation.votingStyle == VotingStyle.QUALITY ){
				// copy qualityRanking, but don't include yourself
				int indexInCurrentList = 0;
				for( int j = 0; j < nationCount; j++ ){
					Nation n = qualityRanking.get(j);
					if( !n.equals( currentNation )){
						currentRankingList.set(indexInCurrentList, n);
						indexInCurrentList++;
					}
				}
			}
			
			currentNation.setRankingList( currentRankingList );
			
		}
		HashMap<Nation, Integer> scoreList;
		
		
		// ...and now we're going to optimize
		// only retain nations that can be influenced, so remove yourself
		if( wantedNation.votingStyle == VotingStyle.POLITICAL ){
			politicalNations.remove(wantedNation);
		}
		else if( wantedNation.votingStyle == VotingStyle.QUALITY ){
			qualityNations.remove(wantedNation);
		}
		// now register rank of wanted nation
		for( int i = 0; i < nationCount; i++ ){
			Nation currentNation = qualityRanking.get(i);
			if( !currentNation.equals(wantedNation)){
				currentNation.setRankOfWantedNation( currentNation.getRankingList().indexOf( wantedNation ) + 1 );
			}
		}
		
		// sort according to rank of wanted nation
		Collections.sort(politicalNations);
		Collections.sort(qualityNations);
		
		scoreList = getScore( qualityRanking.getList(), maxPoints );
		int initialScore = 0;
		if( !( scoreList.get(wantedNation) == null ) ){
			initialScore = scoreList.get(wantedNation);
		}
		int maxScore = initialScore;
		
		// we can only gain extra points from political nations
		if( !politicalNations.isEmpty() ){
			// whatever nation we choose, we will feel punishment of all quality-voting nations
			// ranking us at position 1..maxPoints
			
			// number of parts available
			int totalParts = nationCount - 1;
			int partsLeft = totalParts;
			
			// determine how many penalty points must be eliminated before seeing improvement
			int totalPenaltyPoints = 0;
			if( !qualityNations.isEmpty() ){
				for( Nation qn : qualityNations ){
					int currentQualityRank = qn.getRankOfWantedNation();
					int currentPenalty = maxPoints - currentQualityRank;
					if( maxPoints < nationCount - 1 ){
						currentPenalty++;
					}
					if( currentPenalty > 0){
						totalPenaltyPoints += currentPenalty;
					}
				}
				//System.out.println("current total penalty: " +totalPenaltyPoints);
			}
			
			// examine potential gains for all political nations (only if we will have point improvement)
			int pointsToGain = 0;
			if( totalPenaltyPoints < totalParts ){
				for( Nation pn : politicalNations ){
					// politicalNations list is sorted, skip nations that already have us at 1st position
					int currentRank = pn.getRankOfWantedNation();
					
					if( currentRank == 1 ){
						continue;
					}
					else {
						int changablePartCount = Math.min(currentRank - 1, partsLeft); 
						
						if( currentRank <= maxPoints + 1 ){
							//System.out.println(changablePartCount +" to " +pn);
							pointsToGain += changablePartCount;
							partsLeft -= changablePartCount;
						}
						else{
							// current rank has a higher number than maxPoints + 1
							// this means there will be parts not gaining any points
							// (for our rank then still has a higher number than maxPoints)
							pointsToGain += maxPoints - ( currentRank - changablePartCount - 1 );
							partsLeft -= changablePartCount;
						}
						if( partsLeft == 0 ){
							break;
						}
					}
				}
			}
			
			int nettoGain = pointsToGain - totalPenaltyPoints;
			if( nettoGain > 0){
				maxScore += nettoGain;
			}
		}
		
		System.out.println( maxScore );
	}
	
	public static HashMap<Nation, Integer> getScore(Nation[] nationList, int maxPoints){
		HashMap<Nation, Integer> scoreList = new HashMap<Nation, Integer>();
		for( int i = 0; i < nationList.length; i++){
			RankingList currentRankingList = nationList[i].getRankingList();
			for( int rank = 1; rank <= maxPoints; rank++ ){
				int pointsGiven = maxPoints - (rank-1);
				Nation receivingNation = currentRankingList.get(rank-1);
				
				int scoreSoFar;
				if( scoreList.get(receivingNation) == null ){
					scoreSoFar = 0;
				}
				else{
					scoreSoFar = scoreList.get(receivingNation);
				}
				
				scoreSoFar += pointsGiven;
				scoreList.put(receivingNation, scoreSoFar);
			}
		}
		return scoreList;
	}

}

class Nation implements Comparable<Nation>{
	String name;
	Location location;
	// rank in overall artistic quality ranking
	int qualityRank;
	VotingStyle votingStyle;
	// my ranking of all other nations
	RankingList rankingList;
	// rank of nation of interest
	int rankOfWantedNation;
	
	public Nation(String nationName, Location loc, int r, char voting) {
		this.name = nationName;
		this.location = loc;
		this.qualityRank = r;
		votingStyle = VotingStyle.getVotingStyle(voting);
		if(votingStyle == null){
			System.out.println("voting style not recognised!");
		}
		this.rankingList = null;
		this.rankOfWantedNation = -1;
	}
	
	public Location getLocation(){
		return this.location;
	}
	
	public String getName(){
		return this.name;
	}
	
	public void setRankingList(RankingList r){
		this.rankingList = r;
	}
	
	public RankingList getRankingList(){
		return this.rankingList;
	}
	
	public void setRankOfWantedNation( int r ){
		this.rankOfWantedNation = r;
	}
	
	public int getRankOfWantedNation(){
		return this.rankOfWantedNation;
	}
	
	public double distanceTo( Nation other ){
		return this.getLocation().distanceTo(other.getLocation());
	}
	
	public boolean equals( Nation other ){
		return other.getName().equals(this.getName()) && other.getLocation().equals(this.getLocation());
	}
	
	public String toString(){
		return name +" "+location.toString() +" " +this.qualityRank;
	}
	
	public int compareTo(Nation other){
		return this.getRankOfWantedNation() - other.getRankOfWantedNation();
	}
}

class Location{
	int x;
	int y;
	
	public Location(int xCoord, int yCoord){
		this.x = xCoord;
		this.y = yCoord;
	}
	
	public int getX(){
		return x;
	}
	
	public int getY(){
		return y;
	}
	
	public double distanceTo(Location other){
		return Math.sqrt( Math.pow(other.getX()-this.getX(), 2) + Math.pow(other.getY()-this.getY(), 2));
	}
	
	public boolean equals( Location other ){
		return other.getX() == this.getX() && other.getY() == this.getY();
	}
	
	public String toString()
	{
		return "("+this.x+", "+this.y+")";
	}
}

enum VotingStyle{
	POLITICAL, QUALITY;
	
	public static VotingStyle getVotingStyle( char character ){
		if( character == 'p'  ){
			return VotingStyle.POLITICAL;
		}
		else if( character == 'q' ){
			return VotingStyle.QUALITY;
		}
		else{
			return null;
		}
			
	}
}

class RankingList{
	private Nation[] rankingList;
	
	public RankingList(int length){
		rankingList = new Nation[length];
	}
	
	public Nation get( int i ){
		return rankingList[i];
	}
	
	public Nation[] getList(){
		return rankingList;
	}
	
	public void set( int i, Nation n ){
		rankingList[i] = n;
	}
	
	public void promote( Nation n ){
		int nationIndex = indexOf( n );
		if( nationIndex > 0 ){
			Nation temp = get( nationIndex-1 );
			set( nationIndex-1, n );
			set( nationIndex, temp );
		}
	}
	
	public void degrade( Nation n ){
		int nationIndex = indexOf( n );
		if( nationIndex < rankingList.length - 1 ){
			Nation temp = get( nationIndex+1 );
			set( nationIndex+1, n );
			set( nationIndex, temp );
		}
	}
	
	public int indexOf( Nation n ){
		int nationIndex = -1;
		for( int i = 0; i < rankingList.length; i++ ){
			if( rankingList[i].equals(n) ){
				nationIndex = i;
				break;
			}
		}
		return nationIndex;
	}
	
	public String toString(){
		String representation = "";
		for( int i = 1; i <= rankingList.length; i++ ){
			representation += ( i +": " +get(i-1).toString()+'\n' );
		}
		return representation;
	}
}

class PoliticalComparator implements Comparator<Nation>{
	private Nation referenceNation;
	
	public PoliticalComparator( Nation n ){
		referenceNation = n;
	}
	public int compare(Nation firstNation, Nation secondNation) {
		double difference = firstNation.distanceTo(referenceNation) - secondNation.distanceTo(referenceNation);
		int result = (int) Math.signum( difference );
		return result;
	}
	
}
