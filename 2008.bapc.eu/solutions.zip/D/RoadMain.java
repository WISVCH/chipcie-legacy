/*
   Solution in Java
   for the problem Road
   for BAPC 2008
   July 2008
*/

import java.io.*;
import java.util.*;
class ProblemD{

    private static String infile = "d.in";

    public static void main(String args []){
       InputStream is = null;
       try{
          if (args.length > 0) // another inputfile can be given
             infile = args[0]; // as command line argument
          is = new FileInputStream(infile) ;
       }
       catch (IOException iox){
          System.err.println(iox.toString());
       }
       Scanner ir = new Scanner(is);
       int cases = ir.nextInt();
       for (int k = 0; k < cases; k++){
          RoadProblem rp = new RoadProblem(ir);
          rp.solve();
          System.out.println(rp.getSolution());
      }
    }
}

class RoadProblem{
   private static final int 
      MAXROADLENGTH = 30000,
      MAXCARS       = 1000 ;


    int roadLength;
    int [] passingPlaces;
    int fromWest;
    int fromEast;
    Crossing [] [] crossings;

    public RoadProblem(Scanner sc){
       roadLength = sc.nextInt();
       if (roadLength < 0 || roadLength > MAXROADLENGTH)
          alarm ("roadlength " + roadLength + " not in range");
       int noOfPassingPlaces = sc.nextInt();
       passingPlaces = new int [noOfPassingPlaces + 2];
       passingPlaces[0] = 0;
       for (int k = 1; k <= noOfPassingPlaces; k++){
          passingPlaces[k] = sc.nextInt();
          if (passingPlaces[k] - passingPlaces[k-1] < 30)
             alarm(" error in passingPlaces ");
          if (passingPlaces[k] > roadLength - 30)
             alarm(" error in passingPlaces ");
       }
       passingPlaces[noOfPassingPlaces + 1] = roadLength;
       fromWest = sc.nextInt();
       if (fromWest <= 0 || fromWest > MAXCARS)
         alarm ("Number of cars from West out of range " + fromWest);

       fromEast = sc.nextInt();
       if (fromEast <= 0 || fromEast > MAXCARS)
         alarm ("Number of cars from East out of range " + fromEast);

       crossings = new Crossing [fromWest][fromEast];
       for (int k = 0; k < fromWest; k++)
          for (int m = 0; m < fromEast; m++){
             int pass =  sc.nextInt();
             crossings[k][m] = new Crossing(passingPlaces[pass]);
          }
       checkCrossings();
    }
    
    private void checkCrossings(){
       for (int k = 1; k < fromWest; k++)
          for (int m = 1; m < fromEast; m++){
             if (crossings[k][m].where >  crossings[k-1][m].where)
                alarm(" crossing klopt niet bij (e,w) = (" + k + "," + m + ")");
             if (crossings [k][m].where < crossings [k][m-1].where)
                alarm(" crossing klopt niet bij (e,w) = (" + k + "," + m + ")");
              if (crossings [k-1][m].where == crossings [k][m-1].where
                   && crossings[k-1][m].where > 0 
                   && crossings[k-1][m].where < passingPlaces.length - 1)
                alarm(" crossing klopt niet bij (e,w) = (" + k + "," + m + ")");
          }

    }

    public void solve(){
       for (int k = 0; k < fromWest; k++)
          for (int m = 0; m < fromEast; m++){
             Crossing current = crossings[k][m];
             if (k > 0){
                Crossing east = crossings[k-1][m];
                int distance = east.getWhere() - current.getWhere();
                current.setTime(east.getTime() + seconds(distance));
                if (distance == 0)

                   current.setTime(east.getTime() + 2);
             }
             else
               current.setTime (seconds(roadLength - current.getWhere()));
             if (m > 0){
                Crossing west = crossings[k][m-1];
                int distance =  current.getWhere() - west.getWhere() ;
                current.setTime(west.getTime() + seconds(distance));
                if (distance == 0)
                   current.setTime(west.getTime() + 2);
             }
             else
               current.setTime(seconds(current.getWhere()));
          }
    }

    public String getSolution(){
       Crossing lastCrossing = crossings[fromWest -1][fromEast-1];
       double lastTime = lastCrossing.getTime();
       int where = lastCrossing.getWhere();
       int dist = Math.max(where, roadLength - where);
       double answer = lastTime + seconds(dist);
       double part = answer - (int) answer;
       if (Math. abs( part - 0.5) < 1.0E-3)
          System.out.println(" possible rounding problem : " + answer);
       return "" + (int) Math.round(lastTime + seconds(dist));
    }

    private static double seconds(int dist){
       return dist / 12.5;
    }
    
    private void dump(){
        for (int k = 0; k < fromWest; k++){
          for (int m = 0; m < fromEast; m++){
             System.out.print(crossings[k][m]);
          }
          System.out.println();
        }
    }
    
    private void alarm(String reden){
       throw new RuntimeException(reden);
    }
}

class Crossing{
   int where;
   private double time;

   public Crossing(int pass){
      where = pass;
   }
   
   public void setTime(double newTime){
      if (newTime > time)
         time = newTime;
   }

   public double getTime(){
      return time;
   }
   
   public int getWhere(){
      return where;
   }

   public String toString(){
      return " (" + where + "," + time + ") ";
   }
}
