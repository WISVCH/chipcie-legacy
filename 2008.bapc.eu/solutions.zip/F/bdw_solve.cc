#include <cstdio>
#include <vector>
#include <map>
#include <algorithm>
#include <errno.h>

using namespace std;

#define FOR(i,a,b) for(int i=(a); i<(b); ++i)
#define FORE(i,a,b) for(int i=(a); i<=(b); ++i)
#define REP(i,n) FOR(i,0,n)
#define REPE(i,n) FORE(i,0,n)
#define REPSZ(i,v) REP(i,(int)(v).size())
#define NP(v) next_permutation((v).begin(),(v).end())

typedef pair<int,int> PII;

#define MAXCARDS 10000

int _cardvalue[256];
#define cardvalue(x) _cardvalue[(unsigned)(x)]

void init() {
	REP(i,8) {
		cardvalue('2'+i) = 2+i;
	}
	cardvalue('T') = cardvalue('J') = cardvalue('Q') = cardvalue('K') = 10;
	cardvalue('A') = 1;
}

char card[MAXCARDS+1];
int cards, minbet, maxbet;

int value[MAXCARDS+1];
int next[MAXCARDS+1];

PII play_dealer(int handvalue, int ic, bool have_ace, int playervalue) {

	int base = value[ic];

	/* when dealer has no ace, this is a bust */

	if( handvalue > 21 ) {
	
		if( have_ace ) return play_dealer(handvalue-10, ic, false, playervalue);

		return PII(maxbet + base, ic);
	}

	/* dealer stands > 16 */

	if( handvalue > 16 ) {

		if( handvalue < playervalue ) return PII(maxbet + base, ic);

		else if( handvalue == playervalue ) return PII(base, ic);

		else return PII(-minbet + base, ic);
	}

	/* the dealer must hit when value < 17 */

	if( ic >= cards ) return PII(0, -1);

	handvalue += cardvalue(card[ic]);

	if( card[ic] == 'A' && !have_ace ) {

		return play_dealer(handvalue+10, ic+1, true, playervalue);
	}

	return play_dealer(handvalue, ic+1, have_ace, playervalue);
}

PII play_player(int handvalue, int ic, bool have_ace, int dealer_ic) {

	/* if value > 21, we bust only when no ace*/

	if( handvalue > 21 ) {
	
		if( have_ace ) return play_player(handvalue-10, ic, false, dealer_ic);

		return (ic <= cards) ? PII(-minbet + value[ic], ic) : PII(-minbet, -1);
	}

	int dealer = cardvalue(card[dealer_ic]) + cardvalue(card[dealer_ic+2]);

	bool dealer_ace = ( card[dealer_ic] == 'A' || card[dealer_ic+2] == 'A' );

	if( dealer_ace ) dealer += 10;

	/* first option: stand, dealer starts playing */

	PII val = play_dealer(dealer, ic, dealer_ace, handvalue);

	if( ic >= cards ) {
		
		/* no cards left in the deck, we could hit, so minimum score is 0 */

		if( val.first > 0 ) return val;
		
		else return PII(0,-1);
	}

	if( card[ic] == 'A' && !have_ace ) {

		/* hit an ace and play it as 11 */

		PII x = play_player(10 + handvalue + cardvalue(card[ic]), ic+1, true, dealer_ic);

		if( x > val ) val = x;

	} else {

		/* hit a card and play */

		PII x = play_player(handvalue + cardvalue(card[ic]), ic+1, have_ace, dealer_ic);

		if( x > val ) val = x;
	}

	return val;
}

PII play_hand(int ic) {

	/* we need at least 4 cards to play */

	if( ic + 4 > cards ) return PII(0,-1);

	int player = cardvalue(card[ic]) + cardvalue(card[ic+2]);

	/* no options: the player is not allowed to bust when ace count as 11 */

	if( card[ic] == 'A' || card[ic+2] == 'A' ) {

		return play_player(player+10, ic+4, true, ic+1);

	} else {

		return play_player(player, ic+4, false, ic+1);
	}
}

void run() {

	static int casenr = 1;

	scanf("%d%d%d", &cards, &minbet, &maxbet);

	REP(k,(cards+59)/60) scanf("%s", card + 60*k);

	for( int x = cards; x >= 0; --x ) {

		PII res = play_hand(x);

		value[x] = res.first;

		next[x] = res.second;
	}

	int x = 0;

	while( x < cards && x >= 0 ) {

		x = next[x];
	}

	++casenr;

	printf("%d\n", value[0]);
}

int main(int argc, char *argv[]) {

	if( argc > 1 ) {

		FILE *f = freopen(argv[1], "rt", stdin);

		if( !f ) {

			return 1;
		}
	}

	init();

	int n; scanf("%d", &n);

	while( n-- ) run();

	return 0;
}


