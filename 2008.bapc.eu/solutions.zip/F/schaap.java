import java.io.*;
import java.util.*;

class ProblemF {
    static Scanner s;
    public static void main( String[] args ) {
        try {
            if( args.length > 0 )
                s = new Scanner( new FileInputStream( args[0] ) );
            else
                s = new Scanner( new FileInputStream( "f.in" ) );
            int n = s.nextInt( );
            while( n-- > 0 )
                doTestCase( );
        }
        catch( Exception e ) {
            throw new RuntimeException( e );
        }
    }

    static int[] cards = new int[10000];
    static int c;
    static int p;
    static int q;
    static int[] cache = new int[10000];

    static void doTestCase( ) {
        int i, j, k;
        c = s.nextInt( );
        p = s.nextInt( );
        q = s.nextInt( );
        for( i = 0; i < c; i++ ) {
            cache[i] = 0x80000000;
        }
        j = 0;
        while( i > 0 ) {
            String buf = s.next( );
            for( k = 0; k < buf.length( ); k++ ) {
                switch( buf.charAt( k ) ) {
                    case '2' :
                    case '3' :
                    case '4' :
                    case '5' :
                    case '6' :
                    case '7' :
                    case '8' :
                    case '9' :
                        cards[j++] = buf.charAt( k ) - '0';
                        break;
                    case 'T' :
                    case 'J' :
                    case 'Q' :
                    case 'K' :
                        cards[j++] = 10;
                        break;
                    case 'A' :
                        cards[j++] = 11;
                        break;
                    default :
                }
            }
            i -= 60;
        }
        int solved = solve( 0 );
        System.out.printf( "%d\n", solved );
    }

    static int solve( int start ) {
        // The following four are for CHECKANSWER
        if( cache[start] != 0x80000000 )
            return cache[start];
        int nWins = 0;
        int nLosses = 0;
        int nEquals = 0;
        int[] wins = new int[20];
        int[] losses = new int[20];
        int[] equals = new int[20];
        int myhand = 0;
        int bankhand = 0;
        int nmyaces = 0;
        int nbankaces = 0;
        int max = 0x80000000;
        int temp,z;
        int i = start;
        int j, k, l, m;
        if( i + 3 >= c ) {
            cache[start] = 0;
            return 0;
        }
        myhand = cards[i] + cards[i+2];
        if( cards[i] == 11 )
            nmyaces += 10;
        if( cards[i+2] == 11 )
            nmyaces += 10;
        bankhand = cards[i+1] + cards[i+3];
        if( cards[i+1] == 11 )
            nbankaces += 10;
        if( cards[i+3] == 11 )
            nbankaces += 10;
        i += 4;
        while( myhand - nmyaces <= 21 ) {
            j = i;
            k = bankhand;
            l = nbankaces;
            m = myhand;
            while( myhand > 21 ) /* Possible because dead is checked earlier */
                myhand -= 10;
            while( bankhand > 21 && nbankaces != 0 ) { /* Possible because dead is checked earlier */
                bankhand -= 10;
                nbankaces -= 10;
            }
            while( true ) {
                if( bankhand - nbankaces > 21 ) {
                    wins[nWins++] = i;
                    break;
                }
                else if( bankhand >= 17 ) {
                    if( myhand < bankhand )
                        losses[nLosses++] = i;
                    else if( myhand > bankhand )
                        wins[nWins++] = i;
                    else
                        equals[nEquals++] = i;
                    break;
                }
                if( i == c ) {
                    equals[nEquals++] = i;
                    break;
                }
                if( cards[i] == 11 )
                    nbankaces += 10;
                bankhand += cards[i++];
                while( bankhand > 21 && nbankaces != 0 ) { /* Possible because dead is checked earlier */
                    bankhand -= 10;
                    nbankaces -= 10;
                }
            }
            i = j;
            bankhand = k;
            nbankaces = l;
            myhand = m;
            if( i == c ) {
                equals[nEquals++] = i;
                break;
            }
            if( cards[i] == 11 )
                nmyaces += 10;
            myhand += cards[i++];
            if( myhand - nmyaces > 21 ) {
                losses[nLosses++] = i;
                break;
            }
        }
        /* If I can win this hand, win this hand */
        if( nWins != 0 ) {
            for( z = 0; z < nWins; z++ ) {
                temp = solve( wins[z] );
                if( temp+q > max ) {
                    max = temp+q;
                }
            }
        }
        /* If I can't win this hand, but I can play equal, do so */
        if( nEquals != 0 ) {
            for( z = 0; z < nEquals; z++ ) {
                temp = solve( equals[z] );
                if( temp > max ) {
                    max = temp;
                }
            }
        }
        /* If I can't win nor go equal, I will lose */
        if( nLosses != 0 ) {
            for( z = 0; z < nLosses; z++ ) {
                temp = solve( losses[z] );
                if( temp - p > max ) {
                    max = temp - p;
                }
            }
        }
        cache[start] = max;
        return max;
    }
}
