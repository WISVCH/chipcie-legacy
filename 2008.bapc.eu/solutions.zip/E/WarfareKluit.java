import java.util.*;
import java.io.*;
class ProblemE{

   private static String infile = "e.in";

    public static void main(String args []){
       InputStream is = null;
       try{
            if( args.length > 0 )
                is = new FileInputStream(args[0]);
            else
               is = new FileInputStream(infile) ;
       }
       catch (IOException iox){
            System.err.println(iox.toString());
       }
       Scanner ir = new Scanner(is);
       int cases = ir.nextInt();
       for (int k = 0; k < cases; k++){
          WarProblem wp = new WarProblem(ir);

          wp.solve();
          System.out.println(wp.getSolution());
      }
    }
}

class WarProblem{
   private static final int MAXTOWERS = 100;

   Tower[] towers;
   int allPower;
   int nonBroken;

   public WarProblem(Scanner sc){
      int noOfTowers = sc.nextInt();
      assert (noOfTowers > 2);
      assert (noOfTowers <= MAXTOWERS);
      Tower.noOfTowers = noOfTowers;
      towers = new Tower [noOfTowers];
      for (int k = 0; k < noOfTowers; k++){
	     Tower t = new Tower(sc);
         towers[t.id] = t;

         allPower += towers[t.id].getPower();
      }
   }

   public void solve(){
      for (int k = 0; k < towers.length; k++){
         int minkey = 1;
         Tower champTower = null;
         for (Tower tower: towers)
            if (tower.key < minkey){
               minkey = tower.key;
               champTower = tower;
            }
         nonBroken += minkey;
         champTower.key = 3;
         for (int n : champTower.neighbours)
            towers[n].updateKey(champTower.power);
      }
   }

   public String getSolution(){
      return ""+ (allPower + nonBroken);
   }

}

class Tower{
   
   public static int noOfTowers;

   int power;
   int id;
   int [] neighbours;
   int key = 0;
   int nearest;

   public Tower(Scanner sc){
      id = sc.nextInt();
      assert(id >= 0);
      assert(id <= noOfTowers - 1);

      power = - sc.nextInt();
      int noOfNeighbours = sc.nextInt();
      assert(noOfNeighbours < noOfTowers);
      neighbours = new int [noOfNeighbours];
      for (int k = 0; k < noOfNeighbours; k++){
         neighbours[k] = sc.nextInt();
         assert (neighbours[k] < noOfTowers);
      }
   }
   
   public int getPower(){
      return - power * neighbours.length;
   }

   public void updateKey(int p){
      if (key < 3)
         key = Math.min(key, power + p);
   }

}
